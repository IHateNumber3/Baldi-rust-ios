mod gamedata;

use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::prelude::*;
use bevy::window::{CursorGrabMode, PrimaryWindow};
use std::collections::VecDeque;

// ---------- карта ----------
// # стена, . пол, P игрок, B Балди, N блокнот, E выход
const MAP: [&str; 12] = [
    "#####################",
    "#P...#.......#.....N#",
    "#....#...N...#......#",
    "#....#.......#...#..#",
    "#N........#.......#.#",
    "#....#....#...#.....#",
    "###.####..#####.#####",
    "#.........#.........#",
    "#.N.......#.....N...#",
    "#....#.............E#",
    "#B...#.....N........#",
    "#####################",
];
const CELL: f32 = 3.0;
const WALL_H: f32 = 3.0;

const SPEED: f32 = 4.0;
const SENS: f32 = 0.0025;
const TOUCH_LOOK_MULT: f32 = 3.5;
const PLAYER_R: f32 = 0.4;
const STICK_R: f32 = 70.0;

fn map_w() -> i32 { MAP[0].len() as i32 }
fn map_h() -> i32 { MAP.len() as i32 }
fn cell_of(p: Vec3) -> (i32, i32) {
    ((p.x / CELL + 0.5).floor() as i32, (p.z / CELL + 0.5).floor() as i32)
}
fn center(c: i32, r: i32) -> Vec3 { Vec3::new(c as f32 * CELL, 0.0, r as f32 * CELL) }
fn is_wall(c: i32, r: i32) -> bool {
    if c < 0 || r < 0 || c >= map_w() || r >= map_h() { return true; }
    MAP[r as usize].as_bytes()[c as usize] == b'#'
}
fn blocked(x: f32, z: f32, rad: f32) -> bool {
    for (dx, dz) in [(-rad, -rad), (rad, -rad), (-rad, rad), (rad, rad)] {
        let (c, r) = cell_of(Vec3::new(x + dx, 0.0, z + dz));
        if is_wall(c, r) { return true; }
    }
    false
}

/// Следующая клетка на пути from -> to (BFS).
fn bfs_next(from: (i32, i32), to: (i32, i32)) -> Option<(i32, i32)> {
    if from == to { return Some(to); }
    let w = map_w();
    let n = (w * map_h()) as usize;
    let mut prev: Vec<Option<(i32, i32)>> = vec![None; n];
    let mut seen = vec![false; n];
    let mut q = VecDeque::new();
    seen[(from.1 * w + from.0) as usize] = true;
    q.push_back(from);
    while let Some((c, r)) = q.pop_front() {
        if (c, r) == to {
            let mut cur = to;
            while let Some(p) = prev[(cur.1 * w + cur.0) as usize] {
                if p == from { return Some(cur); }
                cur = p;
            }
            return Some(to);
        }
        for (dc, dr) in [(1, 0), (-1, 0), (0, 1), (0, -1)] {
            let (nc, nr) = (c + dc, r + dr);
            if is_wall(nc, nr) { continue; }
            let i = (nr * w + nc) as usize;
            if seen[i] { continue; }
            seen[i] = true;
            prev[i] = Some((c, r));
            q.push_back((nc, nr));
        }
    }
    None
}

// ---------- компоненты / ресурсы ----------
#[derive(Component)] struct Player;
#[derive(Component)] struct PlayerCam;
#[derive(Component)] struct LevelEntity;
#[derive(Component)] struct Notebook;
#[derive(Component)] struct Exit;
#[derive(Component)] struct Baldi;
#[derive(Component)] struct HudText;
#[derive(Component)] struct MsgText;
#[derive(Component)] struct StickBase;
#[derive(Component)] struct StickKnob;

#[derive(PartialEq, Clone, Copy)]
enum Phase { Playing, Won, Lost }

#[derive(Resource)]
struct Game { notebooks: u32, total: u32, phase: Phase }

#[derive(Resource, Default)]
struct TouchInput { move_vec: Vec2, look: Vec2 }

// ---------- main ----------
#[bevy_main]
pub fn main() {
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window { title: "Baldi RS".into(), ..default() }),
            ..default()
        }))
        .insert_resource(ClearColor(Color::BLACK))
        .insert_resource(Game { notebooks: 0, total: 0, phase: Phase::Playing })
        .init_resource::<TouchInput>()
        .add_systems(Startup, (setup, grab_cursor, setup_touch_ui))
        .add_systems(
            Update,
            (
                gather_touch,
                (look, movement, notebooks_and_exit, baldi_ai).after(gather_touch),
                update_touch_ui.after(gather_touch),
                hud,
                restart,
            ),
        )
        .run();
}

// ---------- уровень ----------
fn spawn_level(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mats: &mut Assets<StandardMaterial>,
    game: &mut Game,
) {
    let wall_mat = mats.add(Color::srgb(0.85, 0.8, 0.55));
    let floor_mat = mats.add(Color::srgb(0.45, 0.35, 0.2));
    let ceil_mat = mats.add(Color::srgb(0.8, 0.8, 0.8));
    let nb_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(0.1, 0.3, 0.9),
        emissive: LinearRgba::rgb(0.0, 0.15, 0.6),
        ..default()
    });
    let exit_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(0.1, 0.8, 0.2),
        emissive: LinearRgba::rgb(0.0, 0.6, 0.1),
        ..default()
    });
    let body_mat = mats.add(Color::srgb(0.2, 0.6, 0.25));
    let head_mat = mats.add(Color::srgb(0.9, 0.7, 0.55));

    let wall_mesh = meshes.add(Cuboid::new(CELL, WALL_H, CELL));
    let nb_mesh = meshes.add(Cuboid::new(0.6, 0.08, 0.8));
    let exit_mesh = meshes.add(Cuboid::new(1.6, 2.6, 0.3));
    let body_mesh = meshes.add(Cuboid::new(0.9, 2.0, 0.5));
    let head_mesh = meshes.add(Cuboid::new(0.7, 0.7, 0.7));

    // пол и потолок
    let (w, h) = (map_w() as f32 * CELL, map_h() as f32 * CELL);
    let mid = Vec3::new((map_w() - 1) as f32 * CELL / 2.0, 0.0, (map_h() - 1) as f32 * CELL / 2.0);
    commands.spawn((
        LevelEntity,
        Mesh3d(meshes.add(Cuboid::new(w, 0.1, h))),
        MeshMaterial3d(floor_mat),
        Transform::from_translation(mid + Vec3::new(0.0, -0.05, 0.0)),
    ));
    commands.spawn((
        LevelEntity,
        Mesh3d(meshes.add(Cuboid::new(w, 0.1, h))),
        MeshMaterial3d(ceil_mat),
        Transform::from_translation(mid + Vec3::new(0.0, WALL_H + 0.05, 0.0)),
    ));

    let mut total = 0;
    for (r, row) in MAP.iter().enumerate() {
        for (c, ch) in row.bytes().enumerate() {
            let pos = center(c as i32, r as i32);
            match ch {
                b'#' => {
                    commands.spawn((
                        LevelEntity,
                        Mesh3d(wall_mesh.clone()),
                        MeshMaterial3d(wall_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, WALL_H / 2.0, 0.0)),
                    ));
                }
                b'P' => {
                    commands
                        .spawn((LevelEntity, Player, Transform::from_translation(pos), Visibility::default()))
                        .with_children(|p| {
                            p.spawn((Camera3d::default(), PlayerCam, Transform::from_xyz(0.0, 1.6, 0.0)));
                            p.spawn((
                                PointLight { intensity: 250_000.0, range: 18.0, ..default() },
                                Transform::from_xyz(0.0, 1.6, 0.0),
                            ));
                        });
                }
                b'B' => {
                    commands
                        .spawn((LevelEntity, Baldi, Transform::from_translation(pos), Visibility::default()))
                        .with_children(|b| {
                            b.spawn((
                                Mesh3d(body_mesh.clone()),
                                MeshMaterial3d(body_mat.clone()),
                                Transform::from_xyz(0.0, 1.0, 0.0),
                            ));
                            b.spawn((
                                Mesh3d(head_mesh.clone()),
                                MeshMaterial3d(head_mat.clone()),
                                Transform::from_xyz(0.0, 2.35, 0.0),
                            ));
                        });
                }
                b'N' => {
                    total += 1;
                    commands.spawn((
                        LevelEntity,
                        Notebook,
                        Mesh3d(nb_mesh.clone()),
                        MeshMaterial3d(nb_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, 1.2, 0.0))
                            .with_rotation(Quat::from_rotation_x(0.5)),
                    ));
                }
                b'E' => {
                    commands.spawn((
                        LevelEntity,
                        Exit,
                        Mesh3d(exit_mesh.clone()),
                        MeshMaterial3d(exit_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, 1.3, 0.0)),
                    ));
                }
                _ => {}
            }
        }
    }
    game.total = total;
    game.notebooks = 0;
    game.phase = Phase::Playing;
}

fn setup(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
    mut game: ResMut<Game>,
) {
    let data = gamedata::GameData::locate();
    let _ = data.root; // позже: текстуры и звуки из BALDI_Data
    commands.insert_resource(AmbientLight { color: Color::WHITE, brightness: 250.0 });
    spawn_level(&mut commands, &mut meshes, &mut mats, &mut game);

    commands.spawn((
        HudText,
        Text::new(""),
        TextFont { font_size: 28.0, ..default() },
        TextColor(Color::WHITE),
        Node { position_type: PositionType::Absolute, top: Val::Px(10.0), right: Val::Px(20.0), ..default() },
    ));
    commands.spawn((
        MsgText,
        Text::new(""),
        TextFont { font_size: 40.0, ..default() },
        TextColor(Color::srgb(1.0, 0.9, 0.3)),
        Node { position_type: PositionType::Absolute, top: Val::Percent(40.0), left: Val::Percent(25.0), ..default() },
    ));
}

fn restart(
    mut commands: Commands,
    touches: Res<Touches>,
    mouse: Res<ButtonInput<MouseButton>>,
    keys: Res<ButtonInput<KeyCode>>,
    mut game: ResMut<Game>,
    ents: Query<Entity, With<LevelEntity>>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
) {
    if game.phase == Phase::Playing { return; }
    if !(touches.any_just_pressed() || mouse.just_pressed(MouseButton::Left) || keys.just_pressed(KeyCode::Enter)) {
        return;
    }
    for e in &ents { commands.entity(e).despawn_recursive(); }
    spawn_level(&mut commands, &mut meshes, &mut mats, &mut game);
}

// ---------- игровая логика ----------
fn notebooks_and_exit(
    time: Res<Time>,
    mut commands: Commands,
    mut game: ResMut<Game>,
    mut nbs: Query<(Entity, &mut Transform), (With<Notebook>, Without<Player>, Without<Exit>)>,
    player: Query<&Transform, (With<Player>, Without<Notebook>)>,
    exit: Query<&Transform, (With<Exit>, Without<Notebook>, Without<Player>)>,
) {
    if game.phase != Phase::Playing { return; }
    let Ok(pt) = player.get_single() else { return };
    let pp = Vec2::new(pt.translation.x, pt.translation.z);
    for (e, mut t) in &mut nbs {
        t.rotate_y(time.delta_secs() * 2.0);
        if pp.distance(Vec2::new(t.translation.x, t.translation.z)) < 1.3 {
            game.notebooks += 1;
            commands.entity(e).despawn();
        }
    }
    if let Ok(et) = exit.get_single() {
        if game.notebooks >= game.total
            && pp.distance(Vec2::new(et.translation.x, et.translation.z)) < 1.6
        {
            game.phase = Phase::Won;
        }
    }
}

fn baldi_ai(
    time: Res<Time>,
    mut game: ResMut<Game>,
    player: Query<&Transform, (With<Player>, Without<Baldi>)>,
    mut baldi: Query<&mut Transform, (With<Baldi>, Without<Player>)>,
) {
    if game.phase != Phase::Playing || game.notebooks == 0 { return; }
    let (Ok(pt), Ok(mut bt)) = (player.get_single(), baldi.get_single_mut()) else { return };
    let from = cell_of(bt.translation);
    let to = cell_of(pt.translation);
    let target = if from == to {
        Vec3::new(pt.translation.x, 0.0, pt.translation.z)
    } else {
        match bfs_next(from, to) {
            Some((c, r)) => center(c, r),
            None => return,
        }
    };
    let dir = Vec3::new(target.x - bt.translation.x, 0.0, target.z - bt.translation.z);
    let speed = 1.8 + 0.7 * game.notebooks as f32;
    let step = speed * time.delta_secs();
    if dir.length() > 0.01 {
        let mv = dir.normalize() * step.min(dir.length());
        bt.translation += mv;
        bt.rotation = Quat::from_rotation_y(dir.x.atan2(dir.z));
    }
    let d = Vec2::new(pt.translation.x - bt.translation.x, pt.translation.z - bt.translation.z).length();
    if d < 1.0 {
        game.phase = Phase::Lost;
    }
}

fn hud(
    game: Res<Game>,
    mut hud: Query<&mut Text, (With<HudText>, Without<MsgText>)>,
    mut msg: Query<&mut Text, (With<MsgText>, Without<HudText>)>,
) {
    if let Ok(mut t) = hud.get_single_mut() {
        t.0 = format!("Notebooks: {}/{}", game.notebooks, game.total);
    }
    if let Ok(mut m) = msg.get_single_mut() {
        m.0 = match game.phase {
            Phase::Playing if game.notebooks >= game.total && game.total > 0 => "Find the exit!".into(),
            Phase::Playing => String::new(),
            Phase::Won => "You escaped!\nTap to restart".into(),
            Phase::Lost => "Baldi caught you!\nTap to restart".into(),
        };
    }
}

// ---------- ввод ----------
fn grab_cursor(mut q: Query<&mut Window, With<PrimaryWindow>>) {
    #[cfg(not(any(target_os = "ios", target_os = "android")))]
    if let Ok(mut w) = q.get_single_mut() {
        w.cursor_options.grab_mode = CursorGrabMode::Locked;
        w.cursor_options.visible = false;
    }
    #[cfg(any(target_os = "ios", target_os = "android"))]
    let _ = &mut q;
}

fn gather_touch(
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut input: ResMut<TouchInput>,
) {
    input.move_vec = Vec2::ZERO;
    input.look = Vec2::ZERO;
    let Ok(w) = windows.get_single() else { return };
    let half = w.width() / 2.0;
    for t in touches.iter() {
        if t.start_position().x < half {
            let d = t.position() - t.start_position();
            input.move_vec = (Vec2::new(d.x, -d.y) / STICK_R).clamp_length_max(1.0);
        } else {
            input.look += t.delta();
        }
    }
}

fn setup_touch_ui(mut commands: Commands) {
    commands.spawn((
        StickBase,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Px(STICK_R * 2.0),
            height: Val::Px(STICK_R * 2.0),
            border: UiRect::all(Val::Px(3.0)),
            display: Display::None,
            ..default()
        },
        BorderRadius::MAX,
        BorderColor(Color::srgba(1.0, 1.0, 1.0, 0.5)),
    ));
    commands.spawn((
        StickKnob,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Px(50.0),
            height: Val::Px(50.0),
            display: Display::None,
            ..default()
        },
        BorderRadius::MAX,
        BackgroundColor(Color::srgba(1.0, 1.0, 1.0, 0.4)),
    ));
}

fn update_touch_ui(
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut base: Query<&mut Node, (With<StickBase>, Without<StickKnob>)>,
    mut knob: Query<&mut Node, (With<StickKnob>, Without<StickBase>)>,
) {
    let (Ok(w), Ok(mut b), Ok(mut k)) =
        (windows.get_single(), base.get_single_mut(), knob.get_single_mut()) else { return };
    let half = w.width() / 2.0;
    match touches.iter().find(|t| t.start_position().x < half) {
        Some(t) => {
            let s = t.start_position();
            let d = (t.position() - s).clamp_length_max(STICK_R);
            b.display = Display::Block;
            b.left = Val::Px(s.x - STICK_R);
            b.top = Val::Px(s.y - STICK_R);
            k.display = Display::Block;
            k.left = Val::Px(s.x + d.x - 25.0);
            k.top = Val::Px(s.y + d.y - 25.0);
        }
        None => {
            b.display = Display::None;
            k.display = Display::None;
        }
    }
}

fn look(
    touch: Res<TouchInput>,
    motion: Res<AccumulatedMouseMotion>,
    mut player: Query<&mut Transform, (With<Player>, Without<PlayerCam>)>,
    mut cam: Query<&mut Transform, With<PlayerCam>>,
) {
    let (Ok(mut p), Ok(mut c)) = (player.get_single_mut(), cam.get_single_mut()) else { return };
    let delta = motion.delta + touch.look * TOUCH_LOOK_MULT;
    p.rotate_y(-delta.x * SENS);
    let (mut pitch, _, _) = c.rotation.to_euler(EulerRot::XYZ);
    pitch = (pitch - delta.y * SENS).clamp(-1.5, 1.5);
    c.rotation = Quat::from_rotation_x(pitch);
}

fn movement(
    touch: Res<TouchInput>,
    keys: Res<ButtonInput<KeyCode>>,
    time: Res<Time>,
    game: Res<Game>,
    mut q: Query<&mut Transform, With<Player>>,
) {
    if game.phase != Phase::Playing { return; }
    let Ok(mut t) = q.get_single_mut() else { return };
    let mut dir = Vec3::ZERO;
    if keys.pressed(KeyCode::KeyW) { dir += *t.forward(); }
    if keys.pressed(KeyCode::KeyS) { dir += *t.back(); }
    if keys.pressed(KeyCode::KeyA) { dir += *t.left(); }
    if keys.pressed(KeyCode::KeyD) { dir += *t.right(); }
    let mut mag = 1.0;
    if touch.move_vec != Vec2::ZERO {
        dir = *t.right() * touch.move_vec.x + *t.forward() * touch.move_vec.y;
        mag = touch.move_vec.length();
    }
    dir.y = 0.0;
    let run = if keys.pressed(KeyCode::ShiftLeft) { 1.8 } else { 1.0 };
    let delta = dir.normalize_or_zero() * mag * SPEED * run * time.delta_secs();
    let p = t.translation;
    if !blocked(p.x + delta.x, p.z, PLAYER_R) { t.translation.x += delta.x; }
    if !blocked(t.translation.x, p.z + delta.z, PLAYER_R) { t.translation.z += delta.z; }
}
