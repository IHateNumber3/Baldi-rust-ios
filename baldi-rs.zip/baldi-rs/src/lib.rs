mod gamedata;

use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::prelude::*;
use bevy::window::{CursorGrabMode, PrimaryWindow};

const SPEED: f32 = 4.0;
const SENS: f32 = 0.0025;
const HALF_W: f32 = 1.5; // полуширина коридора
const LEN: f32 = 30.0;

#[derive(Component)]
struct Player;
#[derive(Component)]
struct PlayerCam;

/// Ввод с тача: левая половина экрана — стик движения, правая — поворот камеры.
#[derive(Resource, Default)]
struct TouchInput {
    move_vec: Vec2, // x: вправо, y: вперёд, длина 0..1
    look: Vec2,     // дельта за кадр в пикселях
}

#[derive(Component)]
struct StickBase;
#[derive(Component)]
struct StickKnob;

const STICK_R: f32 = 70.0;

#[bevy_main]
pub fn main() {
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "Baldi RS".into(),
                ..default()
            }),
            ..default()
        }))
        .insert_resource(ClearColor(Color::BLACK))
        .init_resource::<TouchInput>()
        .add_systems(Startup, (setup, grab_cursor, setup_touch_ui))
        .add_systems(Update, (gather_touch, (look, movement).after(gather_touch), update_touch_ui.after(gather_touch)))
        .run();
}

fn setup(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
) {
    let data = gamedata::GameData::locate();
    commands.insert_resource(AmbientLight {
        color: Color::WHITE,
        brightness: 300.0,
    });
    let _ = data.root; // позже: текстуры из BALDI_Data

    let floor = mats.add(Color::srgb(0.45, 0.35, 0.2));
    let wall = mats.add(Color::srgb(0.85, 0.8, 0.55));
    let ceil = mats.add(Color::srgb(0.8, 0.8, 0.8));

    let mut slab = |size: Vec3, pos: Vec3, m: Handle<StandardMaterial>, c: &mut Commands| {
        c.spawn((
            Mesh3d(meshes.add(Cuboid::new(size.x, size.y, size.z))),
            MeshMaterial3d(m),
            Transform::from_translation(pos),
        ));
    };
    slab(Vec3::new(HALF_W * 2.0, 0.1, LEN), Vec3::new(0.0, -0.05, 0.0), floor, &mut commands);
    slab(Vec3::new(HALF_W * 2.0, 0.1, LEN), Vec3::new(0.0, 3.05, 0.0), ceil, &mut commands);
    slab(Vec3::new(0.1, 3.0, LEN), Vec3::new(-HALF_W - 0.05, 1.5, 0.0), wall.clone(), &mut commands);
    slab(Vec3::new(0.1, 3.0, LEN), Vec3::new(HALF_W + 0.05, 1.5, 0.0), wall.clone(), &mut commands);
    slab(Vec3::new(HALF_W * 2.0, 3.0, 0.1), Vec3::new(0.0, 1.5, -LEN / 2.0), wall, &mut commands);

    for z in [-10.0, 0.0, 10.0] {
        commands.spawn((
            PointLight { intensity: 80_000.0, range: 15.0, ..default() },
            Transform::from_xyz(0.0, 2.8, z),
        ));
    }

    commands
        .spawn((Player, Transform::from_xyz(0.0, 0.0, 12.0), Visibility::default()))
        .with_children(|p| {
            p.spawn((Camera3d::default(), PlayerCam, Transform::from_xyz(0.0, 1.6, 0.0)));
        });
}

fn grab_cursor(mut q: Query<&mut Window, With<PrimaryWindow>>) {
    // На iOS/Android захвата курсора нет.
    #[cfg(not(any(target_os = "ios", target_os = "android")))]
    if let Ok(mut w) = q.get_single_mut() {
        w.cursor_options.grab_mode = CursorGrabMode::Locked;
        w.cursor_options.visible = false;
    }
}

fn gather_touch(
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut input: ResMut<TouchInput>,
) {
    input.move_vec = Vec2::ZERO;
    input.look = Vec2::ZERO;
    let Ok(w) = windows.get_single() else { return };
    let half = w.width() / 2.0;
    for t in touches.iter() {
        if t.start_position().x < half {
            let d = t.position() - t.start_position();
            // экранный Y вниз, а «вперёд» — вверх
            let v = Vec2::new(d.x, -d.y) / STICK_R;
            input.move_vec = v.clamp_length_max(1.0);
        } else {
            input.look += t.delta();
        }
    }
}

fn setup_touch_ui(mut commands: Commands) {
    commands.spawn((
        StickBase,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Px(STICK_R * 2.0),
            height: Val::Px(STICK_R * 2.0),
            border: UiRect::all(Val::Px(3.0)),
            display: Display::None,
            ..default()
        },
        BorderRadius::MAX,
        BorderColor(Color::srgba(1.0, 1.0, 1.0, 0.5)),
    ));
    commands.spawn((
        StickKnob,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Px(50.0),
            height: Val::Px(50.0),
            display: Display::None,
            ..default()
        },
        BorderRadius::MAX,
        BackgroundColor(Color::srgba(1.0, 1.0, 1.0, 0.4)),
    ));
}

fn update_touch_ui(
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut base: Query<&mut Node, (With<StickBase>, Without<StickKnob>)>,
    mut knob: Query<&mut Node, (With<StickKnob>, Without<StickBase>)>,
) {
    let (Ok(w), Ok(mut b), Ok(mut k)) =
        (windows.get_single(), base.get_single_mut(), knob.get_single_mut()) else { return };
    let half = w.width() / 2.0;
    let t = touches.iter().find(|t| t.start_position().x < half);
    match t {
        Some(t) => {
            let s = t.start_position();
            let d = (t.position() - s).clamp_length_max(STICK_R);
            b.display = Display::Block;
            b.left = Val::Px(s.x - STICK_R);
            b.top = Val::Px(s.y - STICK_R);
            k.display = Display::Block;
            k.left = Val::Px(s.x + d.x - 25.0);
            k.top = Val::Px(s.y + d.y - 25.0);
        }
        None => {
            b.display = Display::None;
            k.display = Display::None;
        }
    }
}

fn look(
    touch: Res<TouchInput>,
    motion: Res<AccumulatedMouseMotion>,
    mut player: Query<&mut Transform, (With<Player>, Without<PlayerCam>)>,
    mut cam: Query<&mut Transform, With<PlayerCam>>,
) {
    let (Ok(mut p), Ok(mut c)) = (player.get_single_mut(), cam.get_single_mut()) else { return };
    let delta = motion.delta + touch.look * 0.8;
    p.rotate_y(-delta.x * SENS);
    let (mut pitch, _, _) = c.rotation.to_euler(EulerRot::XYZ);
    pitch = (pitch - delta.y * SENS).clamp(-1.5, 1.5);
    c.rotation = Quat::from_rotation_x(pitch);
}

fn movement(
    touch: Res<TouchInput>,
    keys: Res<ButtonInput<KeyCode>>,
    time: Res<Time>,
    mut q: Query<&mut Transform, With<Player>>,
) {
    let Ok(mut t) = q.get_single_mut() else { return };
    let mut dir = Vec3::ZERO;
    if keys.pressed(KeyCode::KeyW) { dir += *t.forward(); }
    if keys.pressed(KeyCode::KeyS) { dir += *t.back(); }
    if keys.pressed(KeyCode::KeyA) { dir += *t.left(); }
    if keys.pressed(KeyCode::KeyD) { dir += *t.right(); }
    dir.y = 0.0;
    if touch.move_vec != Vec2::ZERO {
        dir = *t.right() * touch.move_vec.x + *t.forward() * touch.move_vec.y;
        dir.y = 0.0;
    }
    let run = if keys.pressed(KeyCode::ShiftLeft) { 1.8 } else { 1.0 };
    let mag = if touch.move_vec != Vec2::ZERO { touch.move_vec.length() } else { 1.0 };
    t.translation += dir.normalize_or_zero() * mag * SPEED * run * time.delta_secs();
    t.translation.x = t.translation.x.clamp(-HALF_W + 0.3, HALF_W - 0.3);
    t.translation.z = t.translation.z.clamp(-LEN / 2.0 + 0.3, LEN / 2.0 - 0.3);
}
