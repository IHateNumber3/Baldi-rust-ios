mod gamedata;

use bevy::image::ImageSampler;
use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::prelude::*;
use bevy::render::render_asset::RenderAssetUsages;
use bevy::render::render_resource::{Extent3d, TextureDimension, TextureFormat};
use bevy::window::{CursorGrabMode, PrimaryWindow};
use std::collections::{HashSet, VecDeque};

// ================= карта =================
// # стена, . пол, D дверь, P игрок, B Балди, N блокнот, E выход,
// Z батончик (скорость), A будильник (отвлекает Балди)
const MAP: [&str; 13] = [
    "#########################",
    "#.......#.....A.#.......#",
    "#..N....#..N....#..N....#",
    "#.......#.......#.......#",
    "####D#######D#######D####",
    "#.........#.............#",
    "#P..........Z..........E#",
    "#.............#.........#",
    "####D#######D#######D####",
    "#.......#.......#.......#",
    "#..N..Z.#..N....#..N....#",
    "#.A.....#.......#.....B.#",
    "#########################"
];
const CELL: f32 = 3.0;
const WALL_H: f32 = 3.0;

// ================= настройки =================
const SPEED: f32 = 4.0;
const SENS: f32 = 0.0025;
const TOUCH_LOOK_MULT: f32 = 3.5;
const PLAYER_R: f32 = 0.4;
const STICK_R: f32 = 90.0;     // радиус нарисованного стика
const STICK_FULL: f32 = 45.0;  // px до полной скорости ходьбы
const STICK_DEAD: f32 = 8.0;   // мёртвая зона
const STICK_RUN: f32 = 85.0;   // px, после которых включается бег (шумно!)
const FOV_DEG: f32 = 75.0;

fn map_w() -> i32 { MAP[0].len() as i32 }
fn map_h() -> i32 { MAP.len() as i32 }
fn cell_of(p: Vec3) -> (i32, i32) {
    ((p.x / CELL + 0.5).floor() as i32, (p.z / CELL + 0.5).floor() as i32)
}
fn center(c: i32, r: i32) -> Vec3 { Vec3::new(c as f32 * CELL, 0.0, r as f32 * CELL) }
fn ch_at(c: i32, r: i32) -> u8 {
    if c < 0 || r < 0 || c >= map_w() || r >= map_h() { return b'#'; }
    MAP[r as usize].as_bytes()[c as usize]
}
fn is_wall(c: i32, r: i32) -> bool { ch_at(c, r) == b'#' }

fn blocked(x: f32, z: f32, rad: f32, open: &OpenDoors) -> bool {
    for (dx, dz) in [(-rad, -rad), (rad, -rad), (-rad, rad), (rad, rad)] {
        let (c, r) = cell_of(Vec3::new(x + dx, 0.0, z + dz));
        if is_wall(c, r) { return true; }
        if ch_at(c, r) == b'D' && !open.0.contains(&(c, r)) { return true; }
    }
    false
}

/// Следующая клетка на пути from -> to (BFS, двери для Балди проходимы).
fn bfs_next(from: (i32, i32), to: (i32, i32)) -> Option<(i32, i32)> {
    if from == to { return Some(to); }
    let w = map_w();
    let n = (w * map_h()) as usize;
    let mut prev: Vec<Option<(i32, i32)>> = vec![None; n];
    let mut seen = vec![false; n];
    let mut q = VecDeque::new();
    seen[(from.1 * w + from.0) as usize] = true;
    q.push_back(from);
    while let Some((c, r)) = q.pop_front() {
        if (c, r) == to {
            let mut cur = to;
            while let Some(p) = prev[(cur.1 * w + cur.0) as usize] {
                if p == from { return Some(cur); }
                cur = p;
            }
            return Some(to);
        }
        for (dc, dr) in [(1, 0), (-1, 0), (0, 1), (0, -1)] {
            let (nc, nr) = (c + dc, r + dr);
            if is_wall(nc, nr) { continue; }
            let i = (nr * w + nc) as usize;
            if seen[i] { continue; }
            seen[i] = true;
            prev[i] = Some((c, r));
            q.push_back((nc, nr));
        }
    }
    None
}

// ================= компоненты / ресурсы =================
#[derive(Component)] struct Player;
#[derive(Component)] struct PlayerCam;
#[derive(Component)] struct LevelEntity;
#[derive(Component)] struct Notebook;
#[derive(Component)] struct Exit;
#[derive(Component)] struct HudText;
#[derive(Component)] struct MsgText;
#[derive(Component)] struct StickBase;
#[derive(Component)] struct StickKnob;
#[derive(Component)] struct UseButton;
#[derive(Component)] struct ItemButton;
#[derive(Component)] struct QuizPanel;
#[derive(Component)] struct QuizText;
#[derive(Component)] struct AnswerButton(usize);
#[derive(Component)] struct AnswerText(usize);
#[derive(Component)] struct Baldi { target: Option<Vec3> }
#[derive(Component)] struct Door { cell: (i32, i32), open: bool }
#[derive(Component)] struct ItemPickup(Item);
#[derive(Component)] struct PlacedAlarm { pos: Vec3, timer: Timer }

#[derive(Clone, Copy, PartialEq)]
enum Item { Zesty, Alarm }
impl Item {
    fn name(&self) -> &'static str {
        match self { Item::Zesty => "Zesty Bar", Item::Alarm => "Alarm Clock" }
    }
}

#[derive(PartialEq, Clone, Copy)]
enum Phase { Playing, Quiz, Won, Lost }

struct QuizData { text: String, answers: [i32; 3], correct: usize }

#[derive(Resource)]
struct Game {
    notebooks: u32,
    total: u32,
    anger: u32,
    phase: Phase,
    item: Option<Item>,
    boost: f32,
    quiz: Option<QuizData>,
}

#[derive(Resource, Default)] struct TouchInput { move_vec: Vec2, look: Vec2, run: bool }
#[derive(Resource, Default)] struct Actions { use_: bool, item: bool }
#[derive(Resource, Default)] struct OpenDoors(HashSet<(i32, i32)>);
#[derive(Resource, Default)] struct Noise(Vec<(Vec3, f32)>);
#[derive(Resource)] struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u32 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        (self.0 >> 33) as u32
    }
    fn range(&mut self, n: u32) -> u32 { self.next() % n }
}

#[derive(Resource)]
struct Textures { wall: Handle<Image>, floor: Handle<Image>, ceiling: Handle<Image>, door: Handle<Image>, baldi: Handle<Image> }

#[derive(Resource)]
struct Sounds { step: Handle<AudioSource>, tick: Handle<AudioSource>, pickup: Handle<AudioSource>, door: Handle<AudioSource>, alarm: Handle<AudioSource> }

fn play(commands: &mut Commands, h: &Handle<AudioSource>) {
    commands.spawn((AudioPlayer(h.clone()), PlaybackSettings::DESPAWN));
}

// ================= процедурные текстуры =================
fn hash(x: u32, y: u32) -> u32 {
    let mut h = x.wrapping_mul(374761393).wrapping_add(y.wrapping_mul(668265263));
    h = (h ^ (h >> 13)).wrapping_mul(1274126177);
    h ^ (h >> 16)
}
fn cl(v: i32) -> u8 { v.clamp(0, 255) as u8 }
fn put(d: &mut [u8], w: u32, x: u32, y: u32, c: [u8; 4]) {
    let i = ((y * w + x) * 4) as usize;
    d[i..i + 4].copy_from_slice(&c);
}
fn make_image(w: u32, h: u32, data: Vec<u8>) -> Image {
    let mut img = Image::new(
        Extent3d { width: w, height: h, depth_or_array_layers: 1 },
        TextureDimension::D2,
        data,
        TextureFormat::Rgba8UnormSrgb,
        RenderAssetUsages::default(),
    );
    img.sampler = ImageSampler::nearest();
    img
}
fn noisy(base: [i32; 3], n: i32) -> [u8; 4] { [cl(base[0] + n), cl(base[1] + n), cl(base[2] + n), 255] }

fn tex_wall() -> Image {
    let (w, h) = (64u32, 64u32);
    let mut d = vec![0u8; (w * h * 4) as usize];
    for y in 0..h {
        for x in 0..w {
            let off = if (y / 16) % 2 == 0 { 0 } else { 16 };
            let mortar = y % 16 == 0 || (x + off) % 32 == 0;
            let n = (hash(x, y) % 14) as i32 - 7;
            let base = if mortar { [165, 155, 135] } else { [214, 196, 140] };
            put(&mut d, w, x, y, noisy(base, n));
        }
    }
    make_image(w, h, d)
}
fn tex_floor() -> Image {
    let (w, h) = (64u32, 64u32);
    let mut d = vec![0u8; (w * h * 4) as usize];
    for y in 0..h {
        for x in 0..w {
            let dark = ((x / 32) + (y / 32)) % 2 == 0;
            let n = (hash(x, y) % 12) as i32 - 6;
            let base = if dark { [150, 125, 85] } else { [185, 160, 110] };
            put(&mut d, w, x, y, noisy(base, n));
        }
    }
    make_image(w, h, d)
}
fn tex_ceiling() -> Image {
    let (w, h) = (64u32, 64u32);
    let mut d = vec![0u8; (w * h * 4) as usize];
    for y in 0..h {
        for x in 0..w {
            let line = x % 32 == 0 || y % 32 == 0;
            let n = (hash(x, y) % 10) as i32 - 5;
            let base = if line { [150, 150, 145] } else { [205, 205, 198] };
            put(&mut d, w, x, y, noisy(base, n));
        }
    }
    make_image(w, h, d)
}
fn tex_door() -> Image {
    let (w, h) = (64u32, 64u32);
    let mut d = vec![0u8; (w * h * 4) as usize];
    for y in 0..h {
        for x in 0..w {
            let n = (hash(x, y) % 10) as i32 - 5;
            let border = x < 4 || x >= 60 || y < 4 || y >= 60;
            let panel = (x > 10 && x < 54 && y > 10 && y < 54) && (x < 13 || x > 50 || y < 13 || y > 50);
            let handle = x > 48 && x < 54 && y > 30 && y < 36;
            let base = if handle { [230, 200, 60] } else if border || panel { [80, 48, 20] } else { [125, 78, 36] };
            put(&mut d, w, x, y, noisy(base, n));
        }
    }
    make_image(w, h, d)
}
fn rect(d: &mut [u8], w: u32, x0: u32, y0: u32, x1: u32, y1: u32, c: [u8; 4]) {
    for y in y0..y1 { for x in x0..x1 { put(d, w, x, y, c); } }
}
fn tex_baldi() -> Image {
    let (w, h) = (48u32, 72u32);
    let mut d = vec![0u8; (w * h * 4) as usize];
    let skin = [235, 190, 150, 255];
    rect(&mut d, w, 14, 56, 23, 72, [40, 40, 120, 255]);
    rect(&mut d, w, 25, 56, 34, 72, [40, 40, 120, 255]);
    rect(&mut d, w, 10, 30, 38, 56, [50, 160, 60, 255]);
    rect(&mut d, w, 4, 32, 10, 52, skin);
    rect(&mut d, w, 38, 32, 44, 52, skin);
    rect(&mut d, w, 40, 26, 43, 58, [200, 160, 60, 255]);
    for y in 0..32u32 {
        for x in 0..w {
            let dx = (x as f32 - 24.0) / 12.0;
            let dy = (y as f32 - 16.0) / 15.0;
            if dx * dx + dy * dy <= 1.0 { put(&mut d, w, x, y, skin); }
        }
    }
    rect(&mut d, w, 17, 12, 22, 18, [255, 255, 255, 255]);
    rect(&mut d, w, 26, 12, 31, 18, [255, 255, 255, 255]);
    rect(&mut d, w, 19, 14, 21, 17, [0, 0, 0, 255]);
    rect(&mut d, w, 28, 14, 30, 17, [0, 0, 0, 255]);
    rect(&mut d, w, 19, 24, 29, 26, [150, 30, 30, 255]);
    make_image(w, h, d)
}

fn load_tex(images: &mut Assets<Image>, name: &str, fallback: Image) -> Handle<Image> {
    if let Some(dir) = gamedata::textures_dir() {
        let p = dir.join(format!("{name}.png"));
        if let Ok(img) = image::open(&p) {
            let rgba = img.to_rgba8();
            let (w, h) = rgba.dimensions();
            return images.add(make_image(w, h, rgba.into_raw()));
        }
    }
    images.add(fallback)
}

// ================= процедурные звуки =================
fn wav(samples: &[i16], rate: u32) -> Vec<u8> {
    let data_len = (samples.len() * 2) as u32;
    let mut v: Vec<u8> = Vec::with_capacity(44 + data_len as usize);
    v.extend_from_slice(b"RIFF");
    v.extend_from_slice(&(36 + data_len).to_le_bytes());
    v.extend_from_slice(b"WAVEfmt ");
    v.extend_from_slice(&16u32.to_le_bytes());
    v.extend_from_slice(&1u16.to_le_bytes());
    v.extend_from_slice(&1u16.to_le_bytes());
    v.extend_from_slice(&rate.to_le_bytes());
    v.extend_from_slice(&(rate * 2).to_le_bytes());
    v.extend_from_slice(&2u16.to_le_bytes());
    v.extend_from_slice(&16u16.to_le_bytes());
    v.extend_from_slice(b"data");
    v.extend_from_slice(&data_len.to_le_bytes());
    for s in samples { v.extend_from_slice(&s.to_le_bytes()); }
    v
}
const RATE: u32 = 22050;
fn synth(secs: f32, f: impl Fn(f32, u32) -> f32) -> Vec<i16> {
    let n = (secs * RATE as f32) as u32;
    (0..n).map(|i| (f(i as f32 / RATE as f32, i).clamp(-1.0, 1.0) * 28000.0) as i16).collect()
}
fn src(samples: Vec<i16>) -> AudioSource { AudioSource { bytes: wav(&samples, RATE).into() } }
fn make_sounds(audio: &mut Assets<AudioSource>) -> Sounds {
    let tau = std::f32::consts::TAU;
    let step = synth(0.09, |t, i| ((hash(i, 7) % 2000) as f32 / 1000.0 - 1.0) * (-t * 45.0).exp() * 0.5);
    let tick = synth(0.06, |t, _| (t * 1400.0 * tau).sin() * (-t * 60.0).exp() * 0.7);
    let pickup = synth(0.25, |t, _| {
        let f = if t < 0.1 { 660.0 } else { 880.0 };
        (t * f * tau).sin() * (1.0 - t / 0.25) * 0.5
    });
    let door = synth(0.3, |t, i| {
        ((t * 90.0 * tau).sin() * 0.6 + ((hash(i, 3) % 2000) as f32 / 1000.0 - 1.0) * 0.3) * (-t * 14.0).exp()
    });
    let alarm = synth(1.6, |t, _| {
        let on = ((t * 8.0) as u32) % 2 == 0;
        if on { (t * 1000.0 * tau).sin().signum() * 0.35 } else { 0.0 }
    });
    Sounds {
        step: audio.add(src(step)),
        tick: audio.add(src(tick)),
        pickup: audio.add(src(pickup)),
        door: audio.add(src(door)),
        alarm: audio.add(src(alarm)),
    }
}

// ================= main =================
#[bevy_main]
pub fn main() {
    let seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(12345);
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "Baldi RS".into(),
                #[cfg(any(target_os = "ios", target_os = "android"))]
                resizable: false,
                #[cfg(any(target_os = "ios", target_os = "android"))]
                mode: bevy::window::WindowMode::BorderlessFullscreen(bevy::window::MonitorSelection::Primary),
                ..default()
            }),
            ..default()
        }))
        .insert_resource(ClearColor(Color::BLACK))
        .insert_resource(Game {
            notebooks: 0, total: 0, anger: 0, phase: Phase::Playing,
            item: None, boost: 0.0, quiz: None,
        })
        .insert_resource(Rng(seed | 1))
        .init_resource::<TouchInput>()
        .init_resource::<Actions>()
        .init_resource::<OpenDoors>()
        .init_resource::<Noise>()
        .add_systems(Startup, (setup, grab_cursor, setup_touch_ui, setup_quiz_ui))
        .add_systems(
            Update,
            (
                gather_touch,
                collect_actions,
                look,
                movement,
                use_action,
                item_action,
                pickups,
                alarms,
                baldi_ai,
                baldi_tick,
                door_anim,
                quiz_ui,
                quiz_answer,
                update_touch_ui,
                hud,
                restart,
            )
                .chain(),
        )
        .run();
}

// ================= уровень =================
fn spawn_level(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mats: &mut Assets<StandardMaterial>,
    game: &mut Game,
    open: &mut OpenDoors,
    tex: &Textures,
) {
    let mat = |m: &mut Assets<StandardMaterial>, t: &Handle<Image>| {
        m.add(StandardMaterial { base_color_texture: Some(t.clone()), perceptual_roughness: 1.0, ..default() })
    };
    let wall_mat = mat(mats, &tex.wall);
    let floor_mat = mat(mats, &tex.floor);
    let ceil_mat = mat(mats, &tex.ceiling);
    let door_mat = mat(mats, &tex.door);
    let baldi_mat = mats.add(StandardMaterial {
        base_color_texture: Some(tex.baldi.clone()),
        unlit: true,
        alpha_mode: AlphaMode::Mask(0.5),
        cull_mode: None,
        ..default()
    });
    let nb_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(0.1, 0.3, 0.9),
        emissive: LinearRgba::rgb(0.0, 0.15, 0.6),
        ..default()
    });
    let exit_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(0.1, 0.8, 0.2),
        emissive: LinearRgba::rgb(0.0, 0.6, 0.1),
        ..default()
    });
    let zesty_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(1.0, 0.55, 0.1),
        emissive: LinearRgba::rgb(0.6, 0.25, 0.0),
        ..default()
    });
    let alarm_mat = mats.add(StandardMaterial {
        base_color: Color::srgb(0.9, 0.1, 0.1),
        emissive: LinearRgba::rgb(0.6, 0.0, 0.0),
        ..default()
    });

    let wall_mesh = meshes.add(Cuboid::new(CELL, WALL_H, CELL));
    let floor_mesh = meshes.add(Plane3d::default().mesh().size(CELL, CELL));
    let door_h = meshes.add(Cuboid::new(CELL, WALL_H, 0.3));
    let door_v = meshes.add(Cuboid::new(0.3, WALL_H, CELL));
    let nb_mesh = meshes.add(Cuboid::new(0.6, 0.08, 0.8));
    let exit_mesh = meshes.add(Cuboid::new(1.6, 2.6, 0.3));
    let zesty_mesh = meshes.add(Cuboid::new(0.5, 0.12, 0.25));
    let alarm_mesh = meshes.add(Cuboid::new(0.35, 0.35, 0.2));
    let baldi_mesh = meshes.add(Rectangle::new(1.6, 2.4));

    let mut total = 0;
    for (r, row) in MAP.iter().enumerate() {
        for (c, ch) in row.bytes().enumerate() {
            let (ci, ri) = (c as i32, r as i32);
            let pos = center(ci, ri);
            if ch == b'#' {
                commands.spawn((
                    LevelEntity,
                    Mesh3d(wall_mesh.clone()),
                    MeshMaterial3d(wall_mat.clone()),
                    Transform::from_translation(pos + Vec3::new(0.0, WALL_H / 2.0, 0.0)),
                ));
                continue;
            }
            // пол и потолок
            commands.spawn((
                LevelEntity,
                Mesh3d(floor_mesh.clone()),
                MeshMaterial3d(floor_mat.clone()),
                Transform::from_translation(pos),
            ));
            commands.spawn((
                LevelEntity,
                Mesh3d(floor_mesh.clone()),
                MeshMaterial3d(ceil_mat.clone()),
                Transform::from_translation(pos + Vec3::new(0.0, WALL_H, 0.0))
                    .with_rotation(Quat::from_rotation_x(std::f32::consts::PI)),
            ));
            match ch {
                b'D' => {
                    let horizontal = is_wall(ci - 1, ri) && is_wall(ci + 1, ri);
                    let mesh = if horizontal { door_h.clone() } else { door_v.clone() };
                    commands.spawn((
                        LevelEntity,
                        Door { cell: (ci, ri), open: false },
                        Mesh3d(mesh),
                        MeshMaterial3d(door_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, WALL_H / 2.0, 0.0)),
                    ));
                }
                b'P' => {
                    commands
                        .spawn((LevelEntity, Player, Transform::from_translation(pos), Visibility::default()))
                        .with_children(|p| {
                            p.spawn((
                                Camera3d::default(),
                                Projection::Perspective(PerspectiveProjection {
                                    fov: FOV_DEG.to_radians(),
                                    ..default()
                                }),
                                PlayerCam,
                                Transform::from_xyz(0.0, 1.6, 0.0),
                            ));
                            p.spawn((
                                PointLight { intensity: 250_000.0, range: 18.0, ..default() },
                                Transform::from_xyz(0.0, 1.6, 0.0),
                            ));
                        });
                }
                b'B' => {
                    commands
                        .spawn((LevelEntity, Baldi { target: None }, Transform::from_translation(pos), Visibility::default()))
                        .with_children(|b| {
                            b.spawn((
                                Mesh3d(baldi_mesh.clone()),
                                MeshMaterial3d(baldi_mat.clone()),
                                Transform::from_xyz(0.0, 1.2, 0.0),
                            ));
                        });
                }
                b'N' => {
                    total += 1;
                    commands.spawn((
                        LevelEntity,
                        Notebook,
                        Mesh3d(nb_mesh.clone()),
                        MeshMaterial3d(nb_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, 1.2, 0.0))
                            .with_rotation(Quat::from_rotation_x(0.5)),
                    ));
                }
                b'E' => {
                    commands.spawn((
                        LevelEntity,
                        Exit,
                        Mesh3d(exit_mesh.clone()),
                        MeshMaterial3d(exit_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, 1.3, 0.0)),
                    ));
                }
                b'Z' => {
                    commands.spawn((
                        LevelEntity,
                        ItemPickup(Item::Zesty),
                        Mesh3d(zesty_mesh.clone()),
                        MeshMaterial3d(zesty_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, 1.0, 0.0)),
                    ));
                }
                b'A' => {
                    commands.spawn((
                        LevelEntity,
                        ItemPickup(Item::Alarm),
                        Mesh3d(alarm_mesh.clone()),
                        MeshMaterial3d(alarm_mat.clone()),
                        Transform::from_translation(pos + Vec3::new(0.0, 1.0, 0.0)),
                    ));
                }
                _ => {}
            }
        }
    }
    game.total = total;
    game.notebooks = 0;
    game.anger = 0;
    game.phase = Phase::Playing;
    game.item = None;
    game.boost = 0.0;
    game.quiz = None;
    open.0.clear();
}

fn setup(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
    mut images: ResMut<Assets<Image>>,
    mut audio: ResMut<Assets<AudioSource>>,
    mut game: ResMut<Game>,
    mut open: ResMut<OpenDoors>,
) {
    let _data = gamedata::GameData::locate();
    commands.insert_resource(AmbientLight { color: Color::WHITE, brightness: 250.0 });

    let tex = Textures {
        wall: load_tex(&mut images, "wall", tex_wall()),
        floor: load_tex(&mut images, "floor", tex_floor()),
        ceiling: load_tex(&mut images, "ceiling", tex_ceiling()),
        door: load_tex(&mut images, "door", tex_door()),
        baldi: load_tex(&mut images, "baldi", tex_baldi()),
    };
    commands.insert_resource(make_sounds(&mut audio));
    spawn_level(&mut commands, &mut meshes, &mut mats, &mut game, &mut open, &tex);
    commands.insert_resource(tex);

    commands.spawn((
        HudText,
        Text::new(""),
        TextFont { font_size: 26.0, ..default() },
        TextColor(Color::WHITE),
        Node { position_type: PositionType::Absolute, top: Val::Px(10.0), right: Val::Px(20.0), ..default() },
    ));
    commands.spawn((
        MsgText,
        Text::new(""),
        TextFont { font_size: 40.0, ..default() },
        TextColor(Color::srgb(1.0, 0.9, 0.3)),
        Node { position_type: PositionType::Absolute, top: Val::Percent(40.0), left: Val::Percent(25.0), ..default() },
    ));
}

fn restart(
    mut commands: Commands,
    touches: Res<Touches>,
    mouse: Res<ButtonInput<MouseButton>>,
    keys: Res<ButtonInput<KeyCode>>,
    mut game: ResMut<Game>,
    mut open: ResMut<OpenDoors>,
    tex: Res<Textures>,
    ents: Query<Entity, With<LevelEntity>>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut mats: ResMut<Assets<StandardMaterial>>,
) {
    if game.phase != Phase::Won && game.phase != Phase::Lost { return; }
    if !(touches.any_just_pressed() || mouse.just_pressed(MouseButton::Left) || keys.just_pressed(KeyCode::Enter)) {
        return;
    }
    for e in &ents { commands.entity(e).despawn_recursive(); }
    spawn_level(&mut commands, &mut meshes, &mut mats, &mut game, &mut open, &tex);
}

// ================= UI =================
fn text_node(font: f32) -> (Text, TextFont, TextColor) {
    (Text::new(""), TextFont { font_size: font, ..default() }, TextColor(Color::WHITE))
}

fn setup_touch_ui(mut commands: Commands) {
    commands.spawn((
        StickBase,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Px(STICK_R * 2.0),
            height: Val::Px(STICK_R * 2.0),
            border: UiRect::all(Val::Px(3.0)),
            display: Display::None,
            ..default()
        },
        BorderRadius::MAX,
        BorderColor(Color::srgba(1.0, 1.0, 1.0, 0.5)),
    ));
    commands.spawn((
        StickKnob,
        Node {
            position_type: PositionType::Absolute,
            width: Val::Px(50.0),
            height: Val::Px(50.0),
            display: Display::None,
            ..default()
        },
        BorderRadius::MAX,
        BackgroundColor(Color::srgba(1.0, 1.0, 1.0, 0.4)),
    ));
    let btn = |bottom: f32| Node {
        position_type: PositionType::Absolute,
        right: Val::Percent(5.0),
        bottom: Val::Percent(bottom),
        width: Val::Px(140.0),
        height: Val::Px(84.0),
        justify_content: JustifyContent::Center,
        align_items: AlignItems::Center,
        ..default()
    };
    commands
        .spawn((UseButton, Button, btn(30.0), BackgroundColor(Color::srgba(0.1, 0.6, 0.2, 0.7))))
        .with_children(|b| {
            let (mut t, f, c) = text_node(28.0);
            t.0 = "USE".into();
            b.spawn((t, f, c));
        });
    commands
        .spawn((ItemButton, Button, btn(10.0), BackgroundColor(Color::srgba(0.7, 0.4, 0.1, 0.7))))
        .with_children(|b| {
            let (mut t, f, c) = text_node(28.0);
            t.0 = "ITEM".into();
            b.spawn((t, f, c));
        });
}

fn setup_quiz_ui(mut commands: Commands) {
    commands
        .spawn((
            QuizPanel,
            Node {
                position_type: PositionType::Absolute,
                left: Val::Percent(12.0),
                top: Val::Percent(15.0),
                width: Val::Percent(76.0),
                flex_direction: FlexDirection::Column,
                align_items: AlignItems::Center,
                row_gap: Val::Px(14.0),
                padding: UiRect::all(Val::Px(18.0)),
                display: Display::None,
                ..default()
            },
            BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 0.85)),
        ))
        .with_children(|p| {
            let (t, f, c) = text_node(44.0);
            p.spawn((QuizText, t, f, c));
            p.spawn(Node {
                flex_direction: FlexDirection::Row,
                column_gap: Val::Px(20.0),
                ..default()
            })
            .with_children(|row| {
                for i in 0..3 {
                    row.spawn((
                        AnswerButton(i),
                        Button,
                        Node {
                            width: Val::Px(120.0),
                            height: Val::Px(80.0),
                            justify_content: JustifyContent::Center,
                            align_items: AlignItems::Center,
                            ..default()
                        },
                        BackgroundColor(Color::srgb(0.2, 0.3, 0.7)),
                    ))
                    .with_children(|b| {
                        let (t, f, c) = text_node(36.0);
                        b.spawn((AnswerText(i), t, f, c));
                    });
                }
            });
        });
}

fn quiz_ui(
    game: Res<Game>,
    mut panel: Query<&mut Node, With<QuizPanel>>,
    mut qtext: Query<&mut Text, (With<QuizText>, Without<AnswerText>)>,
    mut atext: Query<(&mut Text, &AnswerText), Without<QuizText>>,
) {
    let show = game.phase == Phase::Quiz;
    if let Ok(mut n) = panel.get_single_mut() {
        n.display = if show { Display::Flex } else { Display::None };
    }
    if let (true, Some(q)) = (show, game.quiz.as_ref()) {
        if let Ok(mut t) = qtext.get_single_mut() { t.0 = q.text.clone(); }
        for (mut t, a) in &mut atext { t.0 = q.answers[a.0].to_string(); }
    }
}

fn quiz_answer(
    mut game: ResMut<Game>,
    mut commands: Commands,
    sounds: Res<Sounds>,
    q: Query<(&Interaction, &AnswerButton), Changed<Interaction>>,
) {
    if game.phase != Phase::Quiz { return; }
    for (i, b) in &q {
        if *i == Interaction::Pressed {
            let Some(quiz) = game.quiz.take() else { return };
            if b.0 == quiz.correct {
                play(&mut commands, &sounds.pickup);
            } else {
                game.anger += 1;
            }
            game.notebooks += 1;
            game.phase = Phase::Playing;
            return;
        }
    }
}

fn hud(
    game: Res<Game>,
    player: Query<&Transform, With<Player>>,
    doors: Query<(&Transform, &Door)>,
    mut hud: Query<&mut Text, (With<HudText>, Without<MsgText>)>,
    mut msg: Query<&mut Text, (With<MsgText>, Without<HudText>)>,
) {
    if let Ok(mut t) = hud.get_single_mut() {
        let item = game.item.map(|i| i.name()).unwrap_or("-");
        let boost = if game.boost > 0.0 { format!("  BOOST {:.0}s", game.boost) } else { String::new() };
        t.0 = format!("Notebooks: {}/{}\nItem: {}{}", game.notebooks, game.total, item, boost);
    }
    let mut near_door = false;
    if let Ok(pt) = player.get_single() {
        let f = *pt.forward();
        let fwd = Vec3::new(f.x, 0.0, f.z).normalize_or_zero();
        for (t, d) in &doors {
            if d.open { continue; }
            let to = Vec3::new(t.translation.x - pt.translation.x, 0.0, t.translation.z - pt.translation.z);
            if to.length() < 3.4 && to.normalize_or_zero().dot(fwd) > 0.3 { near_door = true; }
        }
    }
    if let Ok(mut m) = msg.get_single_mut() {
        m.0 = match game.phase {
            Phase::Playing if near_door => "Tap USE to open the door".into(),
            Phase::Playing if game.notebooks >= game.total && game.total > 0 => "Find the exit!".into(),
            Phase::Won => "You escaped!\nTap to restart".into(),
            Phase::Lost => "Baldi caught you!\nTap to restart".into(),
            _ => String::new(),
        };
    }
}

// ================= ввод =================
fn grab_cursor(mut q: Query<&mut Window, With<PrimaryWindow>>) {
    #[cfg(not(any(target_os = "ios", target_os = "android")))]
    if let Ok(mut w) = q.get_single_mut() {
        w.cursor_options.grab_mode = CursorGrabMode::Locked;
        w.cursor_options.visible = false;
    }
    #[cfg(any(target_os = "ios", target_os = "android"))]
    let _ = &mut q;
}

fn gather_touch(
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut input: ResMut<TouchInput>,
) {
    input.move_vec = Vec2::ZERO;
    input.look = Vec2::ZERO;
    input.run = false;
    let Ok(w) = windows.get_single() else { return };
    let half = w.width() / 2.0;
    for t in touches.iter() {
        if t.start_position().x < half {
            let d = t.position() - t.start_position();
            if d.length() > STICK_DEAD {
                input.move_vec = (Vec2::new(d.x, -d.y) / STICK_FULL).clamp_length_max(1.0);
                input.run = d.length() > STICK_RUN;
            }
        } else {
            input.look += t.delta();
        }
    }
}

fn collect_actions(
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
    use_q: Query<&Interaction, (Changed<Interaction>, With<UseButton>)>,
    item_q: Query<&Interaction, (Changed<Interaction>, With<ItemButton>)>,
    mut act: ResMut<Actions>,
) {
    act.use_ = keys.just_pressed(KeyCode::KeyE)
        || mouse.just_pressed(MouseButton::Left)
        || use_q.iter().any(|i| *i == Interaction::Pressed);
    act.item = keys.just_pressed(KeyCode::KeyF) || item_q.iter().any(|i| *i == Interaction::Pressed);
}

fn update_touch_ui(
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut base: Query<&mut Node, (With<StickBase>, Without<StickKnob>)>,
    mut knob: Query<&mut Node, (With<StickKnob>, Without<StickBase>)>,
) {
    let (Ok(w), Ok(mut b), Ok(mut k)) =
        (windows.get_single(), base.get_single_mut(), knob.get_single_mut()) else { return };
    let half = w.width() / 2.0;
    match touches.iter().find(|t| t.start_position().x < half) {
        Some(t) => {
            let s = t.start_position();
            let d = (t.position() - s).clamp_length_max(STICK_R);
            b.display = Display::Block;
            b.left = Val::Px(s.x - STICK_R);
            b.top = Val::Px(s.y - STICK_R);
            k.display = Display::Block;
            k.left = Val::Px(s.x + d.x - 25.0);
            k.top = Val::Px(s.y + d.y - 25.0);
        }
        None => {
            b.display = Display::None;
            k.display = Display::None;
        }
    }
}

fn look(
    game: Res<Game>,
    touch: Res<TouchInput>,
    motion: Res<AccumulatedMouseMotion>,
    mut player: Query<&mut Transform, (With<Player>, Without<PlayerCam>)>,
    mut cam: Query<&mut Transform, With<PlayerCam>>,
) {
    if game.phase != Phase::Playing { return; }
    let (Ok(mut p), Ok(mut c)) = (player.get_single_mut(), cam.get_single_mut()) else { return };
    let delta = motion.delta + touch.look * TOUCH_LOOK_MULT;
    p.rotate_y(-delta.x * SENS);
    let (mut pitch, _, _) = c.rotation.to_euler(EulerRot::XYZ);
    pitch = (pitch - delta.y * SENS).clamp(-1.5, 1.5);
    c.rotation = Quat::from_rotation_x(pitch);
}

fn movement(
    touch: Res<TouchInput>,
    keys: Res<ButtonInput<KeyCode>>,
    time: Res<Time>,
    game: Res<Game>,
    open: Res<OpenDoors>,
    sounds: Res<Sounds>,
    mut commands: Commands,
    mut noise: ResMut<Noise>,
    mut step_t: Local<f32>,
    mut q: Query<&mut Transform, With<Player>>,
) {
    if game.phase != Phase::Playing { return; }
    let Ok(mut t) = q.get_single_mut() else { return };
    let mut dir = Vec3::ZERO;
    if keys.pressed(KeyCode::KeyW) { dir += *t.forward(); }
    if keys.pressed(KeyCode::KeyS) { dir += *t.back(); }
    if keys.pressed(KeyCode::KeyA) { dir += *t.left(); }
    if keys.pressed(KeyCode::KeyD) { dir += *t.right(); }
    let mut mag = 1.0;
    if touch.move_vec != Vec2::ZERO {
        dir = *t.right() * touch.move_vec.x + *t.forward() * touch.move_vec.y;
        mag = touch.move_vec.length();
    }
    dir.y = 0.0;
    let running = keys.pressed(KeyCode::ShiftLeft) || touch.run;
    let mult = (if running { 1.8 } else { 1.0 }) * (if game.boost > 0.0 { 1.5 } else { 1.0 });
    let delta = dir.normalize_or_zero() * mag * SPEED * mult * time.delta_secs();
    let p = t.translation;
    if !blocked(p.x + delta.x, p.z, PLAYER_R, &open) { t.translation.x += delta.x; }
    if !blocked(t.translation.x, p.z + delta.z, PLAYER_R, &open) { t.translation.z += delta.z; }

    if delta.length() > 0.0001 {
        *step_t -= time.delta_secs();
        if *step_t <= 0.0 {
            play(&mut commands, &sounds.step);
            *step_t = if running { 0.28 } else { 0.5 };
            noise.0.push((t.translation, if running { 14.0 } else { 3.0 }));
        }
    }
}

fn use_action(
    act: Res<Actions>,
    game: Res<Game>,
    sounds: Res<Sounds>,
    mut commands: Commands,
    mut noise: ResMut<Noise>,
    mut open: ResMut<OpenDoors>,
    player: Query<&Transform, With<Player>>,
    mut doors: Query<(&Transform, &mut Door)>,
) {
    if game.phase != Phase::Playing || !act.use_ { return; }
    let Ok(pt) = player.get_single() else { return };
    let fwd = {
        let f = *pt.forward();
        Vec3::new(f.x, 0.0, f.z).normalize_or_zero()
    };
    let mut best: Option<(f32, Vec3, (i32, i32))> = None;
    for (t, d) in &doors {
        if d.open { continue; }
        let to = Vec3::new(t.translation.x - pt.translation.x, 0.0, t.translation.z - pt.translation.z);
        let dist = to.length();
        if dist < 3.4 && to.normalize_or_zero().dot(fwd) > 0.3 {
            if best.map(|b| dist < b.0).unwrap_or(true) {
                best = Some((dist, t.translation, d.cell));
            }
        }
    }
    if let Some((_, pos, cell)) = best {
        for (_, mut d) in &mut doors {
            if d.cell == cell { d.open = true; }
        }
        open.0.insert(cell);
        play(&mut commands, &sounds.door);
        noise.0.push((pos, 10.0));
    }
}

fn door_anim(time: Res<Time>, mut q: Query<(&mut Transform, &Door)>) {
    for (mut t, d) in &mut q {
        if d.open && t.translation.y < 4.8 {
            t.translation.y += 5.0 * time.delta_secs();
        }
    }
}

fn item_action(
    act: Res<Actions>,
    time: Res<Time>,
    mut game: ResMut<Game>,
    mut commands: Commands,
    player: Query<&Transform, With<Player>>,
) {
    game.boost = (game.boost - time.delta_secs()).max(0.0);
    if game.phase != Phase::Playing || !act.item { return; }
    let Some(item) = game.item else { return };
    match item {
        Item::Zesty => game.boost = 6.0,
        Item::Alarm => {
            if let Ok(pt) = player.get_single() {
                commands.spawn((
                    LevelEntity,
                    PlacedAlarm { pos: pt.translation, timer: Timer::from_seconds(3.0, TimerMode::Once) },
                ));
            }
        }
    }
    game.item = None;
}

fn alarms(
    time: Res<Time>,
    sounds: Res<Sounds>,
    mut commands: Commands,
    mut noise: ResMut<Noise>,
    mut q: Query<(Entity, &mut PlacedAlarm)>,
) {
    for (e, mut a) in &mut q {
        a.timer.tick(time.delta());
        if a.timer.finished() {
            noise.0.push((a.pos, 45.0));
            play(&mut commands, &sounds.alarm);
            commands.entity(e).despawn();
        }
    }
}

// ================= игровая логика =================
fn new_quiz(rng: &mut Rng) -> QuizData {
    let a = 1 + rng.range(9) as i32;
    let b = 1 + rng.range(9) as i32;
    let (text, correct) = match rng.range(3) {
        0 => (format!("{} + {} = ?", a, b), a + b),
        1 => (format!("{} - {} = ?", a + b, b), a),
        _ => (format!("{} x {} = ?", a, b), a * b),
    };
    let w1 = correct + 1 + rng.range(3) as i32;
    let w2 = correct - 1 - rng.range(3) as i32;
    let ci = rng.range(3) as usize;
    let mut answers = [0; 3];
    let mut wrongs = [w1, w2].into_iter();
    for (i, slot) in answers.iter_mut().enumerate() {
        *slot = if i == ci { correct } else { wrongs.next().unwrap_or(correct + 5) };
    }
    QuizData { text, answers, correct: ci }
}

fn pickups(
    time: Res<Time>,
    sounds: Res<Sounds>,
    mut commands: Commands,
    mut game: ResMut<Game>,
    mut rng: ResMut<Rng>,
    mut nbs: Query<(Entity, &mut Transform), (With<Notebook>, Without<Player>, Without<Exit>, Without<ItemPickup>)>,
    mut items: Query<(Entity, &mut Transform, &ItemPickup), (Without<Player>, Without<Notebook>, Without<Exit>)>,
    player: Query<&Transform, (With<Player>, Without<Notebook>, Without<ItemPickup>, Without<Exit>)>,
    exit: Query<&Transform, (With<Exit>, Without<Notebook>, Without<Player>, Without<ItemPickup>)>,
) {
    for (_, mut t) in &mut nbs { t.rotate_y(time.delta_secs() * 2.0); }
    for (_, mut t, _) in &mut items { t.rotate_y(time.delta_secs() * 2.0); }
    if game.phase != Phase::Playing { return; }
    let Ok(pt) = player.get_single() else { return };
    let pp = Vec2::new(pt.translation.x, pt.translation.z);

    for (e, t) in &nbs {
        if pp.distance(Vec2::new(t.translation.x, t.translation.z)) < 1.3 {
            commands.entity(e).despawn();
            game.quiz = Some(new_quiz(&mut rng));
            game.phase = Phase::Quiz;
            return;
        }
    }
    for (e, t, it) in &items {
        if game.item.is_none() && pp.distance(Vec2::new(t.translation.x, t.translation.z)) < 1.2 {
            game.item = Some(it.0);
            play(&mut commands, &sounds.pickup);
            commands.entity(e).despawn();
        }
    }
    if let Ok(et) = exit.get_single() {
        if game.notebooks >= game.total && pp.distance(Vec2::new(et.translation.x, et.translation.z)) < 1.6 {
            game.phase = Phase::Won;
        }
    }
}

fn baldi_ai(
    time: Res<Time>,
    sounds: Res<Sounds>,
    mut commands: Commands,
    mut game: ResMut<Game>,
    mut rng: ResMut<Rng>,
    mut noise: ResMut<Noise>,
    mut open: ResMut<OpenDoors>,
    player: Query<&Transform, (With<Player>, Without<Baldi>)>,
    mut baldi: Query<(&mut Transform, &mut Baldi), Without<Player>>,
    mut doors: Query<&mut Door>,
) {
    let (Ok(pt), Ok((mut bt, mut b))) = (player.get_single(), baldi.get_single_mut()) else {
        noise.0.clear();
        return;
    };
    let to_p = Vec3::new(pt.translation.x - bt.translation.x, 0.0, pt.translation.z - bt.translation.z);
    if to_p.length() > 0.01 {
        bt.rotation = Quat::from_rotation_y(to_p.x.atan2(to_p.z));
    }
    if game.phase != Phase::Playing || game.notebooks == 0 {
        noise.0.clear();
        return;
    }

    // слух: чем злее Балди, тем лучше слышит
    let hear_mult = 1.0 + 0.4 * game.anger as f32;
    for (pos, loud) in noise.0.drain(..) {
        if bt.translation.distance(pos) <= loud * hear_mult {
            b.target = Some(pos);
        }
    }
    // «зрение» вблизи
    if to_p.length() < 6.0 {
        b.target = Some(pt.translation);
    }
    // блуждание
    let need_new = match b.target {
        None => true,
        Some(t) => Vec3::new(t.x - bt.translation.x, 0.0, t.z - bt.translation.z).length() < 0.8,
    };
    if need_new {
        for _ in 0..60 {
            let c = rng.range(map_w() as u32) as i32;
            let r = rng.range(map_h() as u32) as i32;
            if !is_wall(c, r) {
                b.target = Some(center(c, r));
                break;
            }
        }
    }

    if let Some(target) = b.target {
        let from = cell_of(bt.translation);
        let tc = cell_of(target);
        let goal = if from == tc {
            Vec3::new(target.x, 0.0, target.z)
        } else {
            match bfs_next(from, tc) {
                Some((c, r)) => center(c, r),
                None => Vec3::new(bt.translation.x, 0.0, bt.translation.z),
            }
        };
        let dir = Vec3::new(goal.x - bt.translation.x, 0.0, goal.z - bt.translation.z);
        let speed = (2.2 + 0.45 * game.notebooks as f32 + 0.7 * game.anger as f32).min(6.5);
        if dir.length() > 0.01 {
            let step = (speed * time.delta_secs()).min(dir.length());
            bt.translation += dir.normalize() * step;
        }
    }

    // Балди открывает двери, через которые идёт
    let bc = cell_of(bt.translation);
    for mut d in &mut doors {
        if !d.open && d.cell == bc {
            d.open = true;
            open.0.insert(d.cell);
            play(&mut commands, &sounds.door);
        }
    }

    let dist = Vec2::new(pt.translation.x - bt.translation.x, pt.translation.z - bt.translation.z).length();
    if dist < 1.0 {
        game.phase = Phase::Lost;
    }
}

fn baldi_tick(
    time: Res<Time>,
    game: Res<Game>,
    sounds: Res<Sounds>,
    mut commands: Commands,
    mut t: Local<f32>,
    player: Query<&Transform, (With<Player>, Without<Baldi>)>,
    baldi: Query<&Transform, (With<Baldi>, Without<Player>)>,
) {
    if game.phase != Phase::Playing || game.notebooks == 0 { return; }
    let (Ok(pt), Ok(bt)) = (player.get_single(), baldi.get_single()) else { return };
    let dist = pt.translation.distance(bt.translation);
    if dist > 30.0 { return; }
    *t -= time.delta_secs();
    if *t <= 0.0 {
        play(&mut commands, &sounds.tick);
        *t = (dist / 20.0).clamp(0.25, 1.2);
    }
}
