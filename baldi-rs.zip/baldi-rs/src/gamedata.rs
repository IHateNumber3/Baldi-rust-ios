//! Поиск папки BALDI_Data у игрока. Ассеты в репозиторий НЕ кладём.
use std::path::PathBuf;

pub struct GameData {
    pub root: Option<PathBuf>,
}

impl GameData {
    pub fn locate() -> Self {
        // iOS: песочница приложения, HOME = контейнер, ресурсы лежат в Documents/
        let docs = std::env::var("HOME").ok().map(|h| PathBuf::from(h).join("Documents"));
        if let Some(d) = &docs {
            let _ = std::fs::create_dir_all(d);
            // iOS показывает папку приложения в «Файлах» только если в Documents что-то лежит
            let readme = d.join("README.txt");
            if !readme.exists() {
                let _ = std::fs::write(&readme, "Put the BALDI_Data folder here.\nPNG overrides go to textures/: wall.png floor.png ceiling.png door.png baldi.png\n");
            }
        }
        let candidates = [
            docs.clone().map(|d| d.join("BALDI_Data")),
            std::env::var("BALDI_DIR").ok().map(PathBuf::from),
            std::env::args().nth(1).map(PathBuf::from),
            Some(PathBuf::from("BALDI_Data")),
            Some(PathBuf::from("Baldi's Basics Classic Remastered/BALDI_Data")),
        ];
        let root = candidates
            .into_iter()
            .flatten()
            .find(|p| p.join("globalgamemanagers").exists());
        match &root {
            Some(p) => info!("BALDI_Data найдена: {}", p.display()),
            None => warn!("BALDI_Data не найдена, работаю на заглушках"),
        }
        Self { root }
    }
}

use bevy::log::{info, warn};

/// Папка с пользовательскими PNG: wall, floor, ceiling, door, baldi (.png).
pub fn textures_dir() -> Option<PathBuf> {
    let base = std::env::var("HOME").ok().map(|h| PathBuf::from(h).join("Documents")).filter(|d| d.exists());
    let dir = base.map(|d| d.join("textures")).unwrap_or_else(|| PathBuf::from("textures"));
    let _ = std::fs::create_dir_all(&dir);
    Some(dir)
}
// TODO: читалка Unity-бандлов (sharedassets*.assets/.resS) для текстур и звуков.
