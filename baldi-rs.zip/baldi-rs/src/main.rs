fn main() {
    baldi_rs::main();
}
