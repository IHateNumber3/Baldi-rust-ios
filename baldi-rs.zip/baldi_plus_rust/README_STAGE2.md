# Baldi's Basics Plus — Rust port, stage 2

This is an incremental headless Rust port, not a complete game yet.

## Implemented in this stage
- `items.rs`: exact `Items` enum order/names from `Items.cs` (including `lostItem0..9`).
- `inventory.rs`: inventory slot core, selection wrap, size adjustment, empty-slot pickup, insert/remove/consume.
- `door.rs`: open/shut/lock/unlock and timed behavior; timer progression follows `dt * environment_time_scale`.
- `warning.rs`: WarningScreen trigger conditions and 1-second unscaled fade state; mobile touch trigger is supported.
- `reference/original_cs/`: extracted original C# files for traceability.

## Not yet ported
Unity object lifecycle, Tile/Cell blocking, item prefabs/effects, HUD, audio, scene transitions,
full ItemManager pickup/use policy, and original DijkstraMap's PathType/navigability rules.
Those need engine adapters and further source-by-source porting.

Use `cargo test` / `cargo check` in a Rust toolchain. This archive has not been verified against an iOS target.
