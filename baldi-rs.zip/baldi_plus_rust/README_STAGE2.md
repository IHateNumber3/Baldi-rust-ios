# Baldi's Basics Plus — incremental Rust port

This repository is an incremental native Rust recreation scaffold, not a complete or faithful game port yet.

## Rust gameplay modules
- `items.rs`: item identifier order from the supplied `Items.cs` reference.
- `inventory.rs`: inventory slot state and selection helpers.
- `door.rs`: door open/shut/lock timers and emitted state events.
- `warning.rs`: warning-screen input/transition state, including touch activation.
- `ios_game.rs`: C ABI game loop state, touch movement, interaction, and one test notebook.

## iOS host
`ios-host/` contains a UIKit renderer, touch joystick, interaction button, and XcodeGen project definition. The renderer currently draws a placeholder first-person corridor and doors; it is not the original game's 3D renderer or asset pipeline.

## Build
The GitHub Actions workflow is `.github/workflows/build-ios.yml`. It builds the Rust static library for `aarch64-apple-ios`, links it into the UIKit app, and packages an unsigned `Baldi.ipa`.

The IPA must be signed for installation. A sideloading tool can sign it with the user's own Apple ID. No Apple signing certificate or provisioning profile is included.
