import UIKit
import QuartzCore

@_silgen_name("baldi_game_reset") private func baldi_game_reset()
@_silgen_name("baldi_game_update") private func baldi_game_update(_ dt: Float)
@_silgen_name("baldi_set_input") private func baldi_set_input(_ x: Float, _ y: Float)
@_silgen_name("baldi_interact") private func baldi_interact()
@_silgen_name("baldi_player_x") private func baldi_player_x() -> Float
@_silgen_name("baldi_player_z") private func baldi_player_z() -> Float
@_silgen_name("baldi_notebooks") private func baldi_notebooks() -> UInt32
@_silgen_name("baldi_notebook_taken") private func baldi_notebook_taken() -> UInt32

final class GameView: UIView {
    private var displayLink: CADisplayLink?
    private var previousTime: CFTimeInterval = 0
    private var joystickTouch: UITouch?
    private var interactTouch: UITouch?
    private var joystickVector = CGVector.zero

    override init(frame: CGRect) {
        super.init(frame: frame)
        isMultipleTouchEnabled = true
        isOpaque = true
        contentScaleFactor = UIScreen.main.scale
        backgroundColor = UIColor.black
        baldi_game_reset()
        let link = CADisplayLink(target: self, selector: #selector(step(_:)))
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    deinit { displayLink?.invalidate() }

    @objc private func step(_ link: CADisplayLink) {
        let dt = previousTime == 0 ? 1.0 / 60.0 : min(link.timestamp - previousTime, 0.05)
        previousTime = link.timestamp
        baldi_game_update(Float(dt))
        setNeedsDisplay()
    }

    private func fill(_ ctx: CGContext, _ points: [CGPoint], _ color: UIColor) {
        guard let first = points.first else { return }
        ctx.beginPath(); ctx.move(to: first)
        for p in points.dropFirst() { ctx.addLine(to: p) }
        ctx.closePath(); ctx.setFillColor(color.cgColor); ctx.fillPath()
    }

    private func text(_ value: String, x: CGFloat, y: CGFloat, size: CGFloat, color: UIColor = .white) {
        (value as NSString).draw(at: CGPoint(x: x, y: y), withAttributes: [
            .font: UIFont.boldSystemFont(ofSize: size), .foregroundColor: color,
            .shadow: NSShadow()
        ])
    }

    override func draw(_ rect: CGRect) {
        guard let c = UIGraphicsGetCurrentContext() else { return }
        let w = bounds.width, h = bounds.height, cx = w * 0.5
        let horizon = h * 0.34
        let px = CGFloat(baldi_player_x()), pz = CGFloat(baldi_player_z())

        c.setFillColor(UIColor(red: 0.43, green: 0.62, blue: 0.75, alpha: 1).cgColor)
        c.fill(CGRect(x: 0, y: 0, width: w, height: horizon))
        fill(c, [CGPoint(x: 0,y: 0), CGPoint(x: w,y: 0), CGPoint(x: cx+18,y: horizon), CGPoint(x: cx-18,y: horizon)], UIColor(red: 0.88, green: 0.85, blue: 0.75, alpha: 1))
        fill(c, [CGPoint(x: 0,y: 0), CGPoint(x: cx-18,y: horizon), CGPoint(x: cx-18,y: h*0.78), CGPoint(x: 0,y: h)], UIColor(red: 0.78, green: 0.72, blue: 0.59, alpha: 1))
        fill(c, [CGPoint(x: w,y: 0), CGPoint(x: cx+18,y: horizon), CGPoint(x: cx+18,y: h*0.78), CGPoint(x: w,y: h)], UIColor(red: 0.72, green: 0.66, blue: 0.54, alpha: 1))
        fill(c, [CGPoint(x: 0,y: h), CGPoint(x: w,y: h), CGPoint(x: cx+18,y: horizon), CGPoint(x: cx-18,y: horizon)], UIColor(red: 0.58, green: 0.51, blue: 0.39, alpha: 1))

        // Floor perspective seams
        c.setStrokeColor(UIColor(white: 0.22, alpha: 0.65).cgColor); c.setLineWidth(2)
        for side in [-1.0, -0.5, 0.5, 1.0] {
            c.move(to: CGPoint(x: cx, y: horizon)); c.addLine(to: CGPoint(x: cx + CGFloat(side)*w, y: h))
        }
        for t in [0.52, 0.66, 0.82] as [CGFloat] {
            let yy = horizon + (h-horizon)*t
            c.move(to: CGPoint(x: cx-(yy-horizon)*0.75, y: yy)); c.addLine(to: CGPoint(x: cx+(yy-horizon)*0.75, y: yy))
        }
        c.strokePath()

        // Door frames on both walls
        drawDoor(c, x: w*0.13, y: h*0.53, width: w*0.15, height: h*0.31)
        drawDoor(c, x: w*0.72, y: h*0.53, width: w*0.15, height: h*0.31)

        // Notebook at the far end of the hall, shrinking with distance.
        if baldi_notebook_taken() == 0 {
            let distance = max(0.7, 8.0 - pz)
            if distance > 0 {
                let scale = min(1.0, 2.8 / distance)
                let bookSize = max(9, 34 * scale)
                let bookX = cx - px * w * 0.055 * scale
                let bookY = horizon + (h-horizon) * min(0.68, 0.28 + pz*0.006)
                c.setFillColor(UIColor(red: 0.12, green: 0.62, blue: 0.25, alpha: 1).cgColor)
                c.fill(CGRect(x: bookX-bookSize/2, y: bookY-bookSize/2, width: bookSize, height: bookSize*0.78))
                c.setStrokeColor(UIColor.white.cgColor); c.setLineWidth(1); c.stroke(CGRect(x: bookX-bookSize/2, y: bookY-bookSize/2, width: bookSize, height: bookSize*0.78))
            }
        }

        // Crosshair and HUD
        c.setStrokeColor(UIColor.white.cgColor); c.setLineWidth(2)
        c.move(to: CGPoint(x: cx-8,y: h*0.51)); c.addLine(to: CGPoint(x: cx+8,y: h*0.51))
        c.move(to: CGPoint(x: cx,y: h*0.51-8)); c.addLine(to: CGPoint(x: cx,y: h*0.51+8)); c.strokePath()
        text("BALDI'S BASICS PLUS — RUST", x: 16, y: 48, size: 14)
        text("NOTEBOOKS: \(baldi_notebooks()) / 1", x: 16, y: 70, size: 18)

        // Touch controls
        let center = joystickCenter
        c.setFillColor(UIColor(white: 1, alpha: 0.16).cgColor)
        c.fillEllipse(in: CGRect(x: center.x-54, y: center.y-54, width: 108, height: 108))
        c.setStrokeColor(UIColor(white: 1, alpha: 0.7).cgColor); c.setLineWidth(2)
        c.strokeEllipse(in: CGRect(x: center.x-54, y: center.y-54, width: 108, height: 108))
        let knob = CGPoint(x: center.x + joystickVector.dx*34, y: center.y - joystickVector.dy*34)
        c.setFillColor(UIColor(white: 1, alpha: 0.55).cgColor)
        c.fillEllipse(in: CGRect(x: knob.x-19, y: knob.y-19, width: 38, height: 38))
        let button = interactRect
        c.setFillColor(UIColor(red: 0.12, green: 0.45, blue: 0.82, alpha: 0.8).cgColor)
        c.fillEllipse(in: button)
        c.setStrokeColor(UIColor.white.cgColor); c.strokeEllipse(in: button)
        text("USE", x: button.midX-15, y: button.midY-9, size: 15)
    }

    private var joystickCenter: CGPoint { CGPoint(x: 82, y: bounds.height-112) }
    private var interactRect: CGRect { CGRect(x: bounds.width-116, y: bounds.height-164, width: 88, height: 88) }

    private func drawDoor(_ c: CGContext, x: CGFloat, y: CGFloat, width: CGFloat, height: CGFloat) {
        c.setFillColor(UIColor(red: 0.34, green: 0.20, blue: 0.12, alpha: 1).cgColor)
        c.fill(CGRect(x: x, y: y, width: width, height: height))
        c.setStrokeColor(UIColor.black.cgColor); c.setLineWidth(4)
        c.stroke(CGRect(x: x, y: y, width: width, height: height))
        c.setFillColor(UIColor.yellow.cgColor)
        c.fillEllipse(in: CGRect(x: x+width*0.78, y: y+height*0.52, width: 6, height: 6))
    }

    private func applyJoystick(_ point: CGPoint) {
        let center = joystickCenter
        var dx = (point.x-center.x)/48
        var dy = (center.y-point.y)/48
        let length = hypot(dx, dy)
        if length > 1 { dx /= length; dy /= length }
        joystickVector = CGVector(dx: dx, dy: dy)
        baldi_set_input(Float(dx), Float(dy))
        setNeedsDisplay()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let p = touch.location(in: self)
            if interactRect.insetBy(dx: -12, dy: -12).contains(p) {
                interactTouch = touch; baldi_interact()
            } else if p.x < bounds.width * 0.48 && p.y > bounds.height * 0.55 {
                joystickTouch = touch; applyJoystick(p)
            }
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let t = joystickTouch, touches.contains(t) { applyJoystick(t.location(in: self)) }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { finishTouches(touches) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { finishTouches(touches) }
    private func finishTouches(_ touches: Set<UITouch>) {
        if let t = joystickTouch, touches.contains(t) {
            joystickTouch = nil; joystickVector = .zero; baldi_set_input(0, 0); setNeedsDisplay()
        }
        if let t = interactTouch, touches.contains(t) { interactTouch = nil }
    }
}
