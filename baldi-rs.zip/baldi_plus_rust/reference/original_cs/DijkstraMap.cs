﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;

// Token: 0x02000132 RID: 306
public class DijkstraMap
{
	// Token: 0x060007AB RID: 1963 RVA: 0x000299C8 File Offset: 0x00027BC8
	public DijkstraMap(EnvironmentController environment, PathType pathType, int maxDistance, params Transform[] target)
	{
		this.environment = environment;
		this.pathType = pathType;
		this.maxDistance = maxDistance;
		this.targets.Clear();
		this.targetPosition = new IntVector2[target.Length];
		if (this.size != environment.levelSize)
		{
			this.size = environment.levelSize;
			this.value = new int[environment.levelSize.x, environment.levelSize.z];
			this.directionToSource = new Direction[environment.levelSize.x, environment.levelSize.z];
		}
		for (int i = 0; i < target.Length; i++)
		{
			this.targets.Add(target[i]);
			this.targetPosition[i] = IntVector2.GetGridPosition(target[i].position);
		}
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x00029AF4 File Offset: 0x00027CF4
	public void Activate()
	{
		this.environment.AddDijkstraMap(this);
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x00029B02 File Offset: 0x00027D02
	public void Deactivate()
	{
		this.environment.RemoveDijkstraMap(this);
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x00029B10 File Offset: 0x00027D10
	public void QueueUpdate()
	{
		this.environment.QueueDijkstraMap(this);
		this.pendingUpdate = true;
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x00029B25 File Offset: 0x00027D25
	public int Value(IntVector2 position)
	{
		return this.value[position.x, position.z];
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x00029B3E File Offset: 0x00027D3E
	public int Value(int x, int z)
	{
		return this.value[x, z];
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x00029B4D File Offset: 0x00027D4D
	public Direction DirectionToSource(IntVector2 position)
	{
		return this.directionToSource[position.x, position.z];
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x060007B2 RID: 1970 RVA: 0x00029B66 File Offset: 0x00027D66
	public bool PendingUpdate
	{
		get
		{
			return this.pendingUpdate;
		}
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x00029B70 File Offset: 0x00027D70
	public bool UpdateIsNeeded()
	{
		for (int i = 0; i < this.targets.Count; i++)
		{
			if (IntVector2.GetGridPosition(this.targets[i].position) != this.targetPosition[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x00029BC0 File Offset: 0x00027DC0
	public void Calculate()
	{
		for (int i = 0; i < this.targets.Count; i++)
		{
			this.targetPosition[i] = IntVector2.GetGridPosition(this.targets[i].position);
		}
		this.Calculate(this.targetPosition);
	}

	// Token: 0x060007B5 RID: 1973 RVA: 0x00029C11 File Offset: 0x00027E11
	public void Calculate(params IntVector2[] goal)
	{
		this.Calculate(this.maxDistance, false, goal);
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x00029C24 File Offset: 0x00027E24
	public void Calculate(int limit, bool storeFoundCells, params IntVector2[] goal)
	{
		this.pendingUpdate = false;
		bool flag = false;
		this.foundCellPositions.Clear();
		for (int i = 0; i < goal.Length; i++)
		{
			if (this.environment.ContainsCoordinates(goal[i]))
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			this._fillQueue.Clear();
			if (this.size != this.environment.levelSize)
			{
				this.size = this.environment.levelSize;
				this.value = new int[this.environment.levelSize.x, this.environment.levelSize.z];
				this.directionToSource = new Direction[this.environment.levelSize.x, this.environment.levelSize.z];
			}
			for (int j = 0; j < this.size.x; j++)
			{
				for (int k = 0; k < this.size.z; k++)
				{
					this.value[j, k] = int.MaxValue;
					this.directionToSource[j, k] = Direction.Null;
				}
			}
			for (int l = 0; l < goal.Length; l++)
			{
				if (this.environment.ContainsCoordinates(goal[l]) && !this.environment.CellFromPosition(goal[l]).Null)
				{
					this.value[goal[l].x, goal[l].z] = 0;
					this._fillQueue.Enqueue(goal[l]);
				}
			}
			while (this._fillQueue.Count > 0)
			{
				IntVector2 intVector = this._fillQueue.Dequeue();
				for (int m = 0; m < 4; m++)
				{
					if (this.value[intVector.x, intVector.z] < limit && this.environment.CellFromPosition(intVector.x, intVector.z).Navigable((Direction)m, this.pathType) && this.environment.ContainsCoordinates(intVector.x + ((Direction)m).ToIntVector2().x, intVector.z + ((Direction)m).ToIntVector2().z) && !this.environment.CellFromPosition(intVector.x + ((Direction)m).ToIntVector2().x, intVector.z + ((Direction)m).ToIntVector2().z).Null && this.value[intVector.x + ((Direction)m).ToIntVector2().x, intVector.z + ((Direction)m).ToIntVector2().z] > this.value[intVector.x, intVector.z] + 1)
					{
						this.value[intVector.x + ((Direction)m).ToIntVector2().x, intVector.z + ((Direction)m).ToIntVector2().z] = this.value[intVector.x, intVector.z] + 1;
						this.directionToSource[intVector.x + ((Direction)m).ToIntVector2().x, intVector.z + ((Direction)m).ToIntVector2().z] = ((Direction)m).GetOpposite();
						IntVector2 item = new IntVector2(intVector.x + ((Direction)m).ToIntVector2().x, intVector.z + ((Direction)m).ToIntVector2().z);
						this._fillQueue.Enqueue(item);
						if (storeFoundCells || this.storeFoundCells)
						{
							this.foundCellPositions.Add(item);
						}
					}
				}
			}
		}
		DijkstraMap.DijkstraMapRecalculated onDijkstraMapRecalculated = this.OnDijkstraMapRecalculated;
		if (onDijkstraMapRecalculated == null)
		{
			return;
		}
		onDijkstraMapRecalculated();
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x00029FF8 File Offset: 0x000281F8
	public List<Cell> FoundCells()
	{
		List<Cell> list = new List<Cell>();
		foreach (IntVector2 position in this.foundCellPositions)
		{
			list.Add(this.environment.CellFromPosition(position));
		}
		return list;
	}

	// Token: 0x170000AC RID: 172
	// (set) Token: 0x060007B8 RID: 1976 RVA: 0x0002A060 File Offset: 0x00028260
	public bool StoreFoundCells
	{
		set
		{
			this.storeFoundCells = value;
		}
	}

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x060007B9 RID: 1977 RVA: 0x0002A069 File Offset: 0x00028269
	public List<IntVector2> FoundCellPositions
	{
		get
		{
			return this.foundCellPositions;
		}
	}

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x060007BA RID: 1978 RVA: 0x0002A071 File Offset: 0x00028271
	public EnvironmentController EnvironmentController
	{
		get
		{
			return this.environment;
		}
	}

	// Token: 0x04000805 RID: 2053
	public DijkstraMap.DijkstraMapRecalculated OnDijkstraMapRecalculated;

	// Token: 0x04000806 RID: 2054
	private EnvironmentController environment;

	// Token: 0x04000807 RID: 2055
	private List<Transform> targets = new List<Transform>();

	// Token: 0x04000808 RID: 2056
	private Direction[,] directionToSource;

	// Token: 0x04000809 RID: 2057
	private IntVector2[] targetPosition = new IntVector2[0];

	// Token: 0x0400080A RID: 2058
	private List<IntVector2> foundCellPositions = new List<IntVector2>();

	// Token: 0x0400080B RID: 2059
	private IntVector2 size;

	// Token: 0x0400080C RID: 2060
	private PathType pathType = PathType.Nav;

	// Token: 0x0400080D RID: 2061
	private int[,] value;

	// Token: 0x0400080E RID: 2062
	private int maxDistance = int.MaxValue;

	// Token: 0x0400080F RID: 2063
	private bool pendingUpdate = true;

	// Token: 0x04000810 RID: 2064
	private bool storeFoundCells;

	// Token: 0x04000811 RID: 2065
	private Queue<IntVector2> _fillQueue = new Queue<IntVector2>();

	// Token: 0x04000812 RID: 2066
	private Queue<IntVector2> _backtrackQueue = new Queue<IntVector2>();

	// Token: 0x0200040D RID: 1037
	// (Invoke) Token: 0x06002150 RID: 8528
	public delegate void DijkstraMapRecalculated();
}
