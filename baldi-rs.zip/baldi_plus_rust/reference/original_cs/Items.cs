﻿using System;

// Token: 0x02000156 RID: 342
public enum Items
{
	// Token: 0x0400097F RID: 2431
	None,
	// Token: 0x04000980 RID: 2432
	Bsoda,
	// Token: 0x04000981 RID: 2433
	ZestyBar,
	// Token: 0x04000982 RID: 2434
	DoorLock,
	// Token: 0x04000983 RID: 2435
	AlarmClock,
	// Token: 0x04000984 RID: 2436
	DetentionKey,
	// Token: 0x04000985 RID: 2437
	Quarter,
	// Token: 0x04000986 RID: 2438
	Map,
	// Token: 0x04000987 RID: 2439
	Wd40,
	// Token: 0x04000988 RID: 2440
	Scissors,
	// Token: 0x04000989 RID: 2441
	NanaPeel,
	// Token: 0x0400098A RID: 2442
	DietBsoda,
	// Token: 0x0400098B RID: 2443
	Teleporter,
	// Token: 0x0400098C RID: 2444
	ChalkEraser,
	// Token: 0x0400098D RID: 2445
	PortalPoster,
	// Token: 0x0400098E RID: 2446
	PrincipalWhistle,
	// Token: 0x0400098F RID: 2447
	Nametag,
	// Token: 0x04000990 RID: 2448
	Tape,
	// Token: 0x04000991 RID: 2449
	Boots,
	// Token: 0x04000992 RID: 2450
	GrapplingHook,
	// Token: 0x04000993 RID: 2451
	Apple,
	// Token: 0x04000994 RID: 2452
	Points,
	// Token: 0x04000995 RID: 2453
	BusPass,
	// Token: 0x04000996 RID: 2454
	CircleKey,
	// Token: 0x04000997 RID: 2455
	TriangleKey,
	// Token: 0x04000998 RID: 2456
	SquareKey,
	// Token: 0x04000999 RID: 2457
	PentagonKey,
	// Token: 0x0400099A RID: 2458
	HexagonKey,
	// Token: 0x0400099B RID: 2459
	WeirdKey,
	// Token: 0x0400099C RID: 2460
	lostItem0,
	// Token: 0x0400099D RID: 2461
	lostItem1,
	// Token: 0x0400099E RID: 2462
	lostItem2,
	// Token: 0x0400099F RID: 2463
	lostItem3,
	// Token: 0x040009A0 RID: 2464
	lostItem4,
	// Token: 0x040009A1 RID: 2465
	lostItem5,
	// Token: 0x040009A2 RID: 2466
	lostItem6,
	// Token: 0x040009A3 RID: 2467
	lostItem7,
	// Token: 0x040009A4 RID: 2468
	lostItem8,
	// Token: 0x040009A5 RID: 2469
	lostItem9,
	// Token: 0x040009A6 RID: 2470
	InvisibilityElixir,
	// Token: 0x040009A7 RID: 2471
	ReachExtender,
	// Token: 0x040009A8 RID: 2472
	StickerPack
}
