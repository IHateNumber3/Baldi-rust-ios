﻿using System;
using System.Collections;
using UnityEngine;
using Object = UnityEngine.Object;

// Token: 0x02000223 RID: 547
public class Door : TileBasedObject
{
	// Token: 0x06000D4C RID: 3404 RVA: 0x0004BCE9 File Offset: 0x00049EE9
	private void Start()
	{
		if (!this.started)
		{
			this.Initialize();
		}
	}

	// Token: 0x06000D4D RID: 3405 RVA: 0x0004BCF9 File Offset: 0x00049EF9
	public virtual void Initialize()
	{
		this.started = true;
	}

	// Token: 0x06000D4E RID: 3406 RVA: 0x0004BD02 File Offset: 0x00049F02
	public virtual void UnInitialize()
	{
		if (this.locked)
		{
			this.Unlock();
		}
	}

	// Token: 0x06000D4F RID: 3407 RVA: 0x0004BD14 File Offset: 0x00049F14
	public virtual void Open(bool cancelTimer, bool makeNoise)
	{
		if (!this.locked)
		{
			if (makeNoise && !this.open)
			{
				this.ec.MakeNoise(base.transform.position + base.transform.forward * this.positionOffset, this.noiseValue);
			}
			this.open = true;
			if (this.closeBlocks)
			{
				this.Block(false);
			}
			if (this.shutTimerInst != null && cancelTimer)
			{
				base.StopCoroutine(this.shutTimerInst);
			}
		}
	}

	// Token: 0x06000D50 RID: 3408 RVA: 0x0004BD9C File Offset: 0x00049F9C
	public virtual void OpenTimed(float time, bool makeNoise)
	{
		if (!this.locked)
		{
			this.Open(false, makeNoise);
			time += (float)(Singleton<StickerManager>.Instance.StickerValue(Sticker.DoorStop) * 10);
			if (time > this.shutTime)
			{
				if (this.shutTimerInst != null)
				{
					base.StopCoroutine(this.shutTimerInst);
				}
				this.shutTimerInst = this.ShutTimer(time);
				base.StartCoroutine(this.shutTimerInst);
			}
		}
	}

	// Token: 0x06000D51 RID: 3409 RVA: 0x0004BE04 File Offset: 0x0004A004
	public virtual void Shut()
	{
		this.open = false;
		if (this.closeBlocks)
		{
			this.Block(true);
		}
		if (this.shutTime > 0f)
		{
			base.StopCoroutine(this.shutTimerInst);
			this.shutTime = 0f;
		}
	}

	// Token: 0x06000D52 RID: 3410 RVA: 0x0004BE40 File Offset: 0x0004A040
	public IEnumerator ShutTimer(float time)
	{
		this.shutTime = time;
		while (this.shutTime > 0f)
		{
			this.shutTime -= Time.deltaTime * this.ec.EnvironmentTimeScale;
			yield return null;
		}
		this.Shut();
		yield break;
	}

	// Token: 0x06000D53 RID: 3411 RVA: 0x0004BE56 File Offset: 0x0004A056
	public virtual void Lock(bool cancelTimer)
	{
		this.locked = true;
		if (this.lockBlocks)
		{
			this.Block(true);
		}
		if (this.unlockTimerInst != null && cancelTimer)
		{
			base.StopCoroutine(this.unlockTimerInst);
		}
	}

	// Token: 0x06000D54 RID: 3412 RVA: 0x0004BE87 File Offset: 0x0004A087
	public virtual void LockTimed(float time)
	{
		this.Lock(false);
		if (time > this.unlockTime)
		{
			if (this.unlockTimerInst != null)
			{
				base.StopCoroutine(this.unlockTimerInst);
			}
			this.unlockTimerInst = this.unlockTimer(time);
			base.StartCoroutine(this.unlockTimerInst);
		}
	}

	// Token: 0x06000D55 RID: 3413 RVA: 0x0004BEC7 File Offset: 0x0004A0C7
	public virtual void Unlock()
	{
		this.locked = false;
		if (this.lockBlocks)
		{
			this.Block(false);
		}
	}

	// Token: 0x06000D56 RID: 3414 RVA: 0x0004BEDF File Offset: 0x0004A0DF
	public virtual void Toggle(bool cancelTimer, bool makeNoise)
	{
		if (this.open)
		{
			this.Shut();
			return;
		}
		this.Open(cancelTimer, makeNoise);
	}

	// Token: 0x06000D57 RID: 3415 RVA: 0x0004BEF8 File Offset: 0x0004A0F8
	public IEnumerator unlockTimer(float time)
	{
		this.unlockTime = time;
		while (this.unlockTime > 0f)
		{
			this.unlockTime -= Time.deltaTime * this.ec.EnvironmentTimeScale;
			yield return null;
		}
		this.Unlock();
		yield break;
	}

	// Token: 0x06000D58 RID: 3416 RVA: 0x0004BF0E File Offset: 0x0004A10E
	public virtual void Block(bool block)
	{
		if (this.blocking != block)
		{
			this.aTile.Block(this.direction, block);
			this.bTile.Block(this.direction.GetOpposite(), block);
		}
		this.blocking = block;
	}

	// Token: 0x17000137 RID: 311
	// (get) Token: 0x06000D59 RID: 3417 RVA: 0x0004BF49 File Offset: 0x0004A149
	public Cell aTile
	{
		get
		{
			return this.ec.cells[this.position.x, this.position.z];
		}
	}

	// Token: 0x17000138 RID: 312
	// (get) Token: 0x06000D5A RID: 3418 RVA: 0x0004BF71 File Offset: 0x0004A171
	public Cell bTile
	{
		get
		{
			return this.ec.cells[this.position.x + this.bOffset.x, this.position.z + this.bOffset.z];
		}
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x0004BFB1 File Offset: 0x0004A1B1
	public Cell CellOnOtherSide(RoomController thisSideRoom)
	{
		if (this.aTile.room != thisSideRoom)
		{
			return this.aTile;
		}
		return this.bTile;
	}

	// Token: 0x06000D5C RID: 3420 RVA: 0x0004BFD4 File Offset: 0x0004A1D4
	public DirectedIntVector2 OtherSideDirectedIntVector2(RoomController thisSideRoom)
	{
		DirectedIntVector2 result = default(DirectedIntVector2);
		if (this.aTile.room != thisSideRoom)
		{
			result.position = this.aTile.position;
			result.direction = this.direction;
		}
		else
		{
			result.position = this.bTile.position;
			result.direction = this.direction.GetOpposite();
		}
		return result;
	}

	// Token: 0x17000139 RID: 313
	// (get) Token: 0x06000D5D RID: 3421 RVA: 0x0004C042 File Offset: 0x0004A242
	public bool IsOpen
	{
		get
		{
			return this.open;
		}
	}

	// Token: 0x04000F63 RID: 3939
	[SerializeField]
	protected float positionOffset = 5f;

	// Token: 0x04000F64 RID: 3940
	private IEnumerator shutTimerInst;

	// Token: 0x04000F65 RID: 3941
	private IEnumerator unlockTimerInst;

	// Token: 0x04000F66 RID: 3942
	private float shutTime;

	// Token: 0x04000F67 RID: 3943
	private float unlockTime;

	// Token: 0x04000F68 RID: 3944
	[Range(0f, 127f)]
	public int noiseValue;

	// Token: 0x04000F69 RID: 3945
	public bool makesNoise = true;

	// Token: 0x04000F6A RID: 3946
	public bool closeBlocks;

	// Token: 0x04000F6B RID: 3947
	public bool lockBlocks = true;

	// Token: 0x04000F6C RID: 3948
	public bool open;

	// Token: 0x04000F6D RID: 3949
	public bool locked;

	// Token: 0x04000F6E RID: 3950
	private bool started;

	// Token: 0x04000F6F RID: 3951
	private bool blocking;
}
