﻿using System;
using UnityEngine;
using Object = UnityEngine.Object;

// Token: 0x02000258 RID: 600
public class ItemManager : MonoBehaviour
{
	// Token: 0x06000E8F RID: 3727 RVA: 0x00051168 File Offset: 0x0004F368
	private void Awake()
	{
		Object.DontDestroyOnLoad(base.gameObject);
		for (int i = 0; i < this.items.Length; i++)
		{
			if (this.items[i] == null)
			{
				this.items[i] = this.nothing;
			}
		}
		this.UpdateTargetInventorySize();
		Singleton<StickerManager>.Instance.OnStickerApplied += this.UpdateTargetInventorySize;
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x000511CD File Offset: 0x0004F3CD
	private void OnDestroy()
	{
		if (Singleton<StickerManager>.Instance != null)
		{
			Singleton<StickerManager>.Instance.OnStickerApplied -= this.UpdateTargetInventorySize;
		}
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x000511F4 File Offset: 0x0004F3F4
	public void UpdateTargetInventorySize()
	{
		this.targetInventorySize = this.defaultInventorySize + Singleton<StickerManager>.Instance.StickerValue(Sticker.InventorySlot) - this.inventoryShrinks;
		this.maxItem = Mathf.Max(this.targetInventorySize, Mathf.Max(this.TotalItemsInInventory, this.MaxSlotWithItem + 1)) - 1;
		Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).UpdateInventorySize(Mathf.Max(this.targetInventorySize, Mathf.Max(this.TotalItemsInInventory, this.MaxSlotWithItem + 1)));
		this.UpdateSelect();
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x00051284 File Offset: 0x0004F484
	private void Update()
	{
		if (this.maxItem >= this.targetInventorySize)
		{
			int num = 0;
			while (num <= this.maxItem && this.maxItem >= this.targetInventorySize)
			{
				if (this.items[num] == this.nothing)
				{
					this.RemoveItemSlot(num);
					num--;
				}
				num++;
			}
		}
		if (Time.timeScale != 0f)
		{
			Singleton<InputManager>.Instance.GetAnalogInput(this.itemAnalogData, out this._absoluteVector, out this._deltaVector, 0.05f);
			if (Mathf.Sign(this.scrollVal) != Mathf.Sign(this._deltaVector.x))
			{
				this.scrollVal = 0f;
			}
			this.scrollVal += this._deltaVector.x;
			if (this.scrollVal > 0.25f || Singleton<InputManager>.Instance.GetDigitalInput("ItemRight", true))
			{
				this.IncreaseItemSelection();
				this.scrollVal = 0f;
			}
			else if (this.scrollVal < -0.25f || Singleton<InputManager>.Instance.GetDigitalInput("ItemLeft", true))
			{
				this.DecreaseItemSelection();
				this.scrollVal = 0f;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("UseItem", true) && !Singleton<PlayerFileManager>.Instance.authenticMode && !this.pm.plm.Entity.InteractionDisabled && this.pm.plm.Entity.InBounds)
			{
				this.UseItem();
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item1", true) && this.maxItem >= 0)
			{
				this.selectedItem = 0;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item2", true) && this.maxItem >= 1)
			{
				this.selectedItem = 1;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item3", true) && this.maxItem >= 2)
			{
				this.selectedItem = 2;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item4", true) && this.maxItem >= 3)
			{
				this.selectedItem = 3;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item5", true) && this.maxItem >= 4)
			{
				this.selectedItem = 4;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item6", true) && this.maxItem >= 5)
			{
				this.selectedItem = 5;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item7", true) && this.maxItem >= 6)
			{
				this.selectedItem = 6;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item8", true) && this.maxItem >= 7)
			{
				this.selectedItem = 7;
				this.UpdateSelect();
				return;
			}
			if (Singleton<InputManager>.Instance.GetDigitalInput("Item9", true) && this.maxItem >= 8)
			{
				this.selectedItem = 8;
				this.UpdateSelect();
			}
		}
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x00051572 File Offset: 0x0004F772
	private void IncreaseItemSelection()
	{
		this.selectedItem++;
		if (this.selectedItem > this.maxItem)
		{
			this.selectedItem = 0;
		}
		this.UpdateSelect();
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x0005159D File Offset: 0x0004F79D
	private void DecreaseItemSelection()
	{
		this.selectedItem--;
		if (this.selectedItem < 0)
		{
			this.selectedItem = Mathf.Max(this.maxItem, 0);
		}
		this.UpdateSelect();
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x000515D0 File Offset: 0x0004F7D0
	public void UpdateSelect()
	{
		if (this.maxItem >= 0)
		{
			Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).SetItemSelect(this.selectedItem, this.items[this.selectedItem].nameKey);
			return;
		}
		Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).SetItemSelect(0, "");
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x0005163C File Offset: 0x0004F83C
	public void UpdateItems()
	{
		for (int i = 0; i <= this.maxItem; i++)
		{
			Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).UpdateItemIcon(i, this.items[i].itemSpriteSmall);
		}
	}

	// Token: 0x06000E97 RID: 3735 RVA: 0x00051684 File Offset: 0x0004F884
	public bool AddItem(ItemObject item, Pickup pickup)
	{
		if (this.maxItem >= 0)
		{
			if (!this.InventoryFull())
			{
				this.AddItem(item);
				return true;
			}
			int num = 0;
			while (this.slotLocked[this.selectedItem] && num <= this.maxItem)
			{
				this.IncreaseItemSelection();
				num++;
			}
			if (!this.slotLocked[this.selectedItem])
			{
				pickup.AssignItem(this.items[this.selectedItem]);
				Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).inventory.LoseItem(this.selectedItem, this.items[this.selectedItem]);
				this.AddItem(item);
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000E98 RID: 3736 RVA: 0x00051738 File Offset: 0x0004F938
	public void AddItem(ItemObject item)
	{
		if (this.maxItem >= 0)
		{
			int num = 0;
			if (this.items[this.selectedItem].itemType == Items.None)
			{
				this.items[this.selectedItem] = item;
				num = this.selectedItem;
			}
			else
			{
				bool flag = false;
				for (int i = 0; i <= this.maxItem; i++)
				{
					if (this.items[i].itemType == Items.None)
					{
						this.items[i] = item;
						flag = true;
						num = i;
						break;
					}
				}
				if (!flag)
				{
					this.items[this.selectedItem] = item;
					num = this.selectedItem;
				}
			}
			Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).UpdateItemIcon(num, this.items[num].itemSpriteSmall);
			Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).inventory.CollectItem(num, item);
			this.UpdateSelect();
		}
	}

	// Token: 0x06000E99 RID: 3737 RVA: 0x00051816 File Offset: 0x0004FA16
	public void SetItem(ItemObject item, int slot)
	{
		this.items[slot] = item;
		Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).UpdateItemIcon(slot, this.items[slot].itemSpriteSmall);
		this.UpdateSelect();
	}

	// Token: 0x06000E9A RID: 3738 RVA: 0x00051850 File Offset: 0x0004FA50
	public void UseItem()
	{
		if (!this.disabled || (this.items[this.selectedItem].overrideDisabled && this.maxItem >= 0))
		{
			Item item = Object.Instantiate<Item>(this.items[this.selectedItem].item);
			if (item.Use(this.pm))
			{
				if (Singleton<CoreGameManager>.Instance.inventoryChallenge)
				{
					this.ReduceTargetInventorySize();
				}
				this.RemoveItem(this.selectedItem);
				if (item != null)
				{
					item.PostUse(this.pm);
				}
			}
		}
	}

	// Token: 0x06000E9B RID: 3739 RVA: 0x000518D8 File Offset: 0x0004FAD8
	public void RemoveItem(int val)
	{
		Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).inventory.LoseItem(val, this.items[val]);
		this.items[val] = this.nothing;
		Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).UpdateItemIcon(val, this.nothing.itemSpriteSmall);
		this.UpdateSelect();
	}

	// Token: 0x06000E9C RID: 3740 RVA: 0x00051947 File Offset: 0x0004FB47
	public void ReduceTargetInventorySize()
	{
		this.inventoryShrinks++;
		this.UpdateTargetInventorySize();
	}

	// Token: 0x06000E9D RID: 3741 RVA: 0x00051960 File Offset: 0x0004FB60
	public void RemoveItemSlot(int val)
	{
		for (int i = val; i < this.maxItem; i++)
		{
			this.SetItem(this.items[i + 1], i);
		}
		this.SetItem(this.nothing, this.maxItem);
		this.UpdateTargetInventorySize();
		this.selectedItem = Mathf.Min(this.selectedItem, Mathf.Max(this.maxItem, 0));
		this.UpdateSelect();
	}

	// Token: 0x06000E9E RID: 3742 RVA: 0x000519CA File Offset: 0x0004FBCA
	public void ResetMaxItem()
	{
		this.inventoryShrinks = 0;
		this.UpdateTargetInventorySize();
	}

	// Token: 0x06000E9F RID: 3743 RVA: 0x000519DC File Offset: 0x0004FBDC
	public void ClearItems()
	{
		for (int i = 0; i < this.items.Length; i++)
		{
			this.items[i] = this.nothing;
			Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).UpdateItemIcon(i, this.nothing.itemSpriteSmall);
		}
		this.UpdateSelect();
	}

	// Token: 0x06000EA0 RID: 3744 RVA: 0x00051A38 File Offset: 0x0004FC38
	public void RemoveRandomItem()
	{
		if (this.HasItem())
		{
			int num = UnityEngine.Random.Range(0, this.maxItem + 1);
			while (this.items[num] == this.nothing && !this.slotLocked[num])
			{
				num = UnityEngine.Random.Range(0, this.maxItem + 1);
			}
			this.RemoveItem(num);
		}
	}

	// Token: 0x06000EA1 RID: 3745 RVA: 0x00051A94 File Offset: 0x0004FC94
	public bool HasItem()
	{
		for (int i = 0; i <= this.maxItem; i++)
		{
			if (this.items[i] != this.nothing && !this.slotLocked[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x1700014A RID: 330
	// (get) Token: 0x06000EA2 RID: 3746 RVA: 0x00051AD4 File Offset: 0x0004FCD4
	public int TotalItemsInInventory
	{
		get
		{
			int num = 0;
			for (int i = 0; i < this.items.Length; i++)
			{
				if (this.items[i] != this.nothing)
				{
					num++;
				}
			}
			return num;
		}
	}

	// Token: 0x1700014B RID: 331
	// (get) Token: 0x06000EA3 RID: 3747 RVA: 0x00051B10 File Offset: 0x0004FD10
	public int MaxSlotWithItem
	{
		get
		{
			for (int i = this.items.Length - 1; i >= 0; i--)
			{
				if (this.items[i] != this.nothing)
				{
					return i;
				}
			}
			return -1;
		}
	}

	// Token: 0x06000EA4 RID: 3748 RVA: 0x00051B4C File Offset: 0x0004FD4C
	public bool Has(Items desiredItem)
	{
		for (int i = 0; i <= this.maxItem; i++)
		{
			if (this.items[i].itemType == desiredItem)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000EA5 RID: 3749 RVA: 0x00051B80 File Offset: 0x0004FD80
	public bool InventoryFull()
	{
		for (int i = 0; i <= this.maxItem; i++)
		{
			if (this.items[i].itemType == Items.None)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000EA6 RID: 3750 RVA: 0x00051BB0 File Offset: 0x0004FDB0
	public void Remove(Items itemToRemove)
	{
		for (int i = 0; i <= this.maxItem; i++)
		{
			if (this.items[i].itemType == itemToRemove)
			{
				Singleton<CoreGameManager>.Instance.GetHud(this.pm.playerNumber).inventory.LoseItem(i, this.items[i]);
				this.RemoveItem(i);
				return;
			}
		}
	}

	// Token: 0x06000EA7 RID: 3751 RVA: 0x00051C0E File Offset: 0x0004FE0E
	public void LockSlot(int slot, bool val)
	{
		if (slot >= 0 && slot <= this.maxItem)
		{
			this.slotLocked[slot] = val;
		}
	}

	// Token: 0x06000EA8 RID: 3752 RVA: 0x00051C26 File Offset: 0x0004FE26
	public void Disable(bool val)
	{
		if (val)
		{
			this.disables++;
			this.disabled = true;
			return;
		}
		this.disables--;
		if (this.disables <= 0)
		{
			this.disabled = false;
			this.disables = 0;
		}
	}

	// Token: 0x040010DC RID: 4316
	public PlayerManager pm;

	// Token: 0x040010DD RID: 4317
	public ItemObject[] items = new ItemObject[9];

	// Token: 0x040010DE RID: 4318
	public ItemObject nothing;

	// Token: 0x040010DF RID: 4319
	public AnalogInputData itemAnalogData;

	// Token: 0x040010E0 RID: 4320
	private Vector2 _absoluteVector;

	// Token: 0x040010E1 RID: 4321
	private Vector2 _deltaVector;

	// Token: 0x040010E2 RID: 4322
	private float scrollVal;

	// Token: 0x040010E3 RID: 4323
	public int selectedItem;

	// Token: 0x040010E4 RID: 4324
	public int maxItem;

	// Token: 0x040010E5 RID: 4325
	public int defaultInventorySize = 5;

	// Token: 0x040010E6 RID: 4326
	private int disables;

	// Token: 0x040010E7 RID: 4327
	private int targetInventorySize = 5;

	// Token: 0x040010E8 RID: 4328
	private int inventoryShrinks;

	// Token: 0x040010E9 RID: 4329
	private bool[] slotLocked = new bool[9];

	// Token: 0x040010EA RID: 4330
	private bool disabled;
}
