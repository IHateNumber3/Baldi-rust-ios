﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;
using Object = UnityEngine.Object;

// Token: 0x0200018B RID: 395
public class WarningScreen : MonoBehaviour
{
	// Token: 0x060009E0 RID: 2528 RVA: 0x000368C0 File Offset: 0x00034AC0
	private void Start()
	{
		if (Singleton<InputManager>.Instance.SteamInputActive)
		{
			this.textBox.text = string.Format(Singleton<LocalizationManager>.Instance.GetLocalizedText("Men_Warning"), Singleton<InputManager>.Instance.GetInputButtonName("MouseSubmit", "Interface", false));
			return;
		}
		this.textBox.text = string.Format(Singleton<LocalizationManager>.Instance.GetLocalizedText("Men_Warning"), "ANY BUTTON");
	}

	// Token: 0x060009E1 RID: 2529 RVA: 0x00036932 File Offset: 0x00034B32
	private void Update()
	{
		if (Input.anyKeyDown || Singleton<InputManager>.Instance.GetDigitalInput("MouseSubmit", true) || Singleton<InputManager>.Instance.GetDigitalInput("Pause", true) || Singleton<InputManager>.Instance.AnyButton(true))
		{
			this.Advance();
		}
	}

	// Token: 0x060009E2 RID: 2530 RVA: 0x00036972 File Offset: 0x00034B72
	private void Advance()
	{
		Singleton<GlobalCam>.Instance.Transition(UiTransition.Dither, 0.01666667f);
		this.blackCover.SetActive(true);
		base.StartCoroutine(this.WaitForTransition());
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x0003699D File Offset: 0x00034B9D
	private IEnumerator WaitForTransition()
	{
		yield return null;
		float time = 1f;
		while (time > 0f)
		{
			time -= Time.unscaledDeltaTime;
			this.audSource.volume = time;
			yield return null;
		}
		this.audSource.Stop();
		yield return null;
		Singleton<AdditiveSceneManager>.Instance.LoadScene(this.scene);
		yield break;
	}

	// Token: 0x04000B36 RID: 2870
	[SerializeField]
	private GameObject blackCover;

	// Token: 0x04000B37 RID: 2871
	public TMP_Text textBox;

	// Token: 0x04000B38 RID: 2872
	[SerializeField]
	private AudioSource audSource;

	// Token: 0x04000B39 RID: 2873
	public string scene;
}
