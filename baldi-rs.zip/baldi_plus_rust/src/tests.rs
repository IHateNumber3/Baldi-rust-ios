use crate::{door::DoorCore, inventory::{AddItemResult,ItemManagerCore}, items::Items, warning::{WarningPhase,WarningScreenCore}};

#[test]
fn item_enum_stable(){assert_eq!(Items::Bsoda as u16,1);assert_eq!(Items::StickerPack as u16,42);}
#[test]
fn inventory_pick_and_consume(){let mut i=ItemManagerCore::new(2,9);assert_eq!(i.pickup_first_empty(Items::Bsoda),AddItemResult::Added(0));assert_eq!(i.selected(),Items::Bsoda);assert_eq!(i.consume_selected(),Items::Bsoda);}
#[test]
fn door_timed_closes(){let mut d=DoorCore::default();d.open_timed(1.0,false,0);assert!(d.open);d.tick(1.1,1.0);assert!(!d.open);}
#[test]
fn warning_accepts_touch(){let mut w=WarningScreenCore::default();w.update(false,false,false,false,true);assert_eq!(w.phase,WarningPhase::Transitioning);w.tick_unscaled(1.1);assert_eq!(w.phase,WarningPhase::Finished);}
