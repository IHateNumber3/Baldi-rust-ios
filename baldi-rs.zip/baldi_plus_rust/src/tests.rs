use crate::items::Items;

#[test]
fn item_enum_stable() {
    assert_eq!(Items::None as u16, 0);
    assert_eq!(Items::WeirdKey as u16, 28);
    assert_eq!(Items::InvisibilityElixir as u16, 39);
    assert_eq!(Items::ReachExtender as u16, 40);
    assert_eq!(Items::StickerPack as u16, 41);
    assert_eq!(Items::COUNT, 42);
}