//! Door timer/state logic translated from Door.cs. Tile/collider updates are emitted as events.
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub enum DoorEvent { Noise, Opened, Shut, Locked, Unlocked, Blocked(bool) }
#[derive(Debug,Clone)]
pub struct DoorCore {
    pub open:bool,pub locked:bool,pub blocking:bool,
    pub close_blocks:bool,pub lock_blocks:bool,
    pub shut_time:f32,pub unlock_time:f32,pub noise_value:f32,
}
impl Default for DoorCore {
 fn default()->Self{Self{open:false,locked:false,blocking:true,close_blocks:true,lock_blocks:true,
 shut_time:0.0,unlock_time:0.0,noise_value:1.0}}
}
impl DoorCore {
 pub fn open(&mut self,cancel_timer:bool,make_noise:bool)->Vec<DoorEvent>{
  let mut e=vec![];if !self.locked{
   if make_noise&&!self.open{e.push(DoorEvent::Noise);}
   self.open=true;if self.close_blocks{self.set_block(false,&mut e);}
   if cancel_timer{self.shut_time=0.0;}
  }e
 }
 pub fn open_timed(&mut self,time:f32,make_noise:bool,door_stop_sticker:i32)->Vec<DoorEvent>{
  let mut e=self.open(false,make_noise);let t=time+(door_stop_sticker*10) as f32;
  if !self.locked&&t>self.shut_time{self.shut_time=t.max(0.0);}e
 }
 pub fn shut(&mut self)->Vec<DoorEvent>{
  let mut e=vec![];self.open=false;if self.close_blocks{self.set_block(true,&mut e);}
  self.shut_time=0.0;e.push(DoorEvent::Shut);e
 }
 pub fn lock(&mut self,cancel_timer:bool)->Vec<DoorEvent>{
  let mut e=vec![];self.locked=true;if self.lock_blocks{self.set_block(true,&mut e);}
  if cancel_timer{self.unlock_time=0.0;}e.push(DoorEvent::Locked);e
 }
 pub fn lock_timed(&mut self,time:f32)->Vec<DoorEvent>{
  let mut e=self.lock(false);if time>self.unlock_time{self.unlock_time=time.max(0.0);}e
 }
 pub fn unlock(&mut self)->Vec<DoorEvent>{
  let mut e=vec![];self.locked=false;if self.lock_blocks{self.set_block(false,&mut e);}
  self.unlock_time=0.0;e.push(DoorEvent::Unlocked);e
 }
 pub fn toggle(&mut self,cancel_timer:bool,noise:bool)->Vec<DoorEvent>{
  if self.open{self.shut()}else{self.open(cancel_timer,noise)}
 }
 /// `dt * environment_time_scale`, matching Door.cs coroutine timer progression.
 pub fn tick(&mut self,dt:f32,environment_time_scale:f32)->Vec<DoorEvent>{
  let step=dt.max(0.0)*environment_time_scale.max(0.0);let mut e=vec![];
  if self.shut_time>0.0{self.shut_time-=step;if self.shut_time<=0.0{e.extend(self.shut());}}
  if self.unlock_time>0.0{self.unlock_time-=step;if self.unlock_time<=0.0{e.extend(self.unlock());}}
  e
 }
 fn set_block(&mut self,v:bool,e:&mut Vec<DoorEvent>){if self.blocking!=v{self.blocking=v;e.push(DoorEvent::Blocked(v));}}
}
