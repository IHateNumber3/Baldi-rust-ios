//! Headless inventory logic. HUD and Unity ItemObject effects are intentionally separate.
use crate::items::Items;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AddItemResult { Added(usize), Replaced(usize), Full, Invalid }
#[derive(Debug, Clone)]
pub struct ItemManagerCore {
    slots: Vec<Items>,
    selected_item: usize,
    target_inventory_size: usize,
    default_inventory_size: usize,
    inventory_shrinks: usize,
}
impl ItemManagerCore {
    pub fn new(default_inventory_size: usize, physical_capacity: usize) -> Self {
        let capacity=physical_capacity.max(default_inventory_size);
        Self { slots:vec![Items::None;capacity], selected_item:0,
            target_inventory_size:default_inventory_size.min(capacity),
            default_inventory_size, inventory_shrinks:0 }
    }
    pub fn slots(&self)->&[Items] { &self.slots }
    pub fn selected_index(&self)->usize { self.selected_item }
    pub fn selected(&self)->Items { self.slots.get(self.selected_item).copied().unwrap_or(Items::None) }
    pub fn target_size(&self)->usize { self.target_inventory_size }
    pub fn total_items(&self)->usize { self.slots.iter().filter(|&&x|x!=Items::None).count() }
    pub fn max_slot_with_item(&self)->Option<usize> { self.slots.iter().rposition(|&x|x!=Items::None) }
    pub fn max_item(&self)->isize {
        self.target_inventory_size.max(self.total_items()).max(self.max_slot_with_item().map_or(0,|i|i+1)) as isize-1
    }
    pub fn update_target_size(&mut self, sticker_inventory_slots:i32) {
        self.target_inventory_size=(self.default_inventory_size as i32+sticker_inventory_slots-self.inventory_shrinks as i32).max(0) as usize;
        self.target_inventory_size=self.target_inventory_size.min(self.slots.len());
        self.selected_item=self.selected_item.min(self.max_item().max(0) as usize);
    }
    pub fn shrink(&mut self, amount:usize) {
        self.inventory_shrinks=self.inventory_shrinks.saturating_add(amount);
        self.update_target_size(0);
    }
    pub fn select(&mut self,index:usize) {
        if self.max_item()>=0 { self.selected_item=index.min(self.max_item() as usize); }
    }
    pub fn next(&mut self) {
        let max=self.max_item().max(0) as usize;
        self.selected_item=if self.selected_item>=max {0}else{self.selected_item+1};
    }
    pub fn previous(&mut self) {
        let max=self.max_item().max(0) as usize;
        self.selected_item=if self.selected_item==0 {max}else{self.selected_item-1};
    }
    /// Explicit slot insertion. `replace_selected` mirrors a pickup policy decision
    /// made by the game/item adapter; no guessed pickup behavior is hidden here.
    pub fn put(&mut self,index:usize,item:Items)->AddItemResult {
        if item==Items::None || index>=self.slots.len(){return AddItemResult::Invalid;}
        let old=self.slots[index];self.slots[index]=item;
        if old==Items::None {AddItemResult::Added(index)} else {AddItemResult::Replaced(index)}
    }
    pub fn pickup_first_empty(&mut self,item:Items)->AddItemResult {
        if item==Items::None{return AddItemResult::Invalid;}
        let limit=self.target_inventory_size.max(self.total_items()).max(self.max_slot_with_item().map_or(0,|i|i+1)).min(self.slots.len());
        if let Some(i)=(0..limit).find(|&i|self.slots[i]==Items::None) {
            self.slots[i]=item;return AddItemResult::Added(i);
        }
        AddItemResult::Full
    }
    pub fn remove(&mut self,index:usize)->Option<Items> {
        let s=self.slots.get_mut(index)?;let item=*s;*s=Items::None;Some(item)
    }
    pub fn consume_selected(&mut self)->Items { self.remove(self.selected_item).unwrap_or(Items::None) }
    pub fn contains(&self,item:Items)->bool {self.slots.iter().any(|&x|x==item)}
    pub fn clear(&mut self){self.slots.fill(Items::None);self.selected_item=0;}
}
