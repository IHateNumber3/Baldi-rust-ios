//! WarningScreen's input/transition state. Scene loading/audio are engine adapter responsibilities.
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub enum WarningPhase { Waiting, Transitioning, Finished }
#[derive(Debug,Clone)]
pub struct WarningScreenCore { pub phase:WarningPhase, pub fade_remaining:f32 }
impl Default for WarningScreenCore{fn default()->Self{Self{phase:WarningPhase::Waiting,fade_remaining:0.0}}}
impl WarningScreenCore{
 /// Original advances on any key, MouseSubmit, Pause, or any mapped button.
 /// Mobile adapter should pass `touch_began=true` for any screen touch.
 pub fn update(&mut self,any_key_down:bool,mouse_submit:bool,pause:bool,any_button:bool,touch_began:bool){
  if self.phase==WarningPhase::Waiting&&(any_key_down||mouse_submit||pause||any_button||touch_began){
   self.phase=WarningPhase::Transitioning;self.fade_remaining=1.0;
  }
 }
 pub fn tick_unscaled(&mut self,dt:f32){
  if self.phase==WarningPhase::Transitioning{self.fade_remaining-=dt.max(0.0);if self.fade_remaining<=0.0{
   self.fade_remaining=0.0;self.phase=WarningPhase::Finished;}}
 }
}
