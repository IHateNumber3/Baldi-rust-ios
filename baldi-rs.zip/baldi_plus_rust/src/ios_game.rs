//! Small playable iOS game loop used as the native-port foundation.
//! Rendering and touch collection live in the UIKit host; game state lives here.
use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
struct GameState {
    player_x: f32,
    player_z: f32,
    input_x: f32,
    input_y: f32,
    notebook_taken: bool,
    notebooks: u32,
    elapsed: f32,
}

impl GameState {
    const fn new() -> Self {
        Self {
            player_x: 0.0,
            player_z: 0.0,
            input_x: 0.0,
            input_y: 0.0,
            notebook_taken: false,
            notebooks: 0,
            elapsed: 0.0,
        }
    }

    fn update(&mut self, dt: f32) {
        let dt = if dt.is_finite() { dt.clamp(0.0, 0.05) } else { 0.0 };
        self.elapsed += dt;
        // Starter movement model. Replace speed/collision with the original Player movement port.
        let speed = 4.0;
        self.player_x = (self.player_x + self.input_x * speed * dt).clamp(-2.25, 2.25);
        self.player_z = (self.player_z + self.input_y * speed * dt).clamp(-1.0, 24.0);
    }

    fn interact(&mut self) {
        if !self.notebook_taken {
            let dx = self.player_x;
            let dz = self.player_z - 8.0;
            if dx * dx + dz * dz <= 2.0 * 2.0 {
                self.notebook_taken = true;
                self.notebooks = self.notebooks.saturating_add(1);
            }
        }
    }
}

static GAME: Mutex<GameState> = Mutex::new(GameState::new());

#[no_mangle]
pub extern "C" fn baldi_game_reset() {
    if let Ok(mut game) = GAME.lock() { *game = GameState::new(); }
}

#[no_mangle]
pub extern "C" fn baldi_game_update(dt: f32) {
    if let Ok(mut game) = GAME.lock() { game.update(dt); }
}

#[no_mangle]
pub extern "C" fn baldi_set_input(x: f32, y: f32) {
    if let Ok(mut game) = GAME.lock() {
        game.input_x = if x.is_finite() { x.clamp(-1.0, 1.0) } else { 0.0 };
        game.input_y = if y.is_finite() { y.clamp(-1.0, 1.0) } else { 0.0 };
    }
}

#[no_mangle]
pub extern "C" fn baldi_interact() {
    if let Ok(mut game) = GAME.lock() { game.interact(); }
}

#[no_mangle]
pub extern "C" fn baldi_player_x() -> f32 {
    GAME.lock().map(|g| g.player_x).unwrap_or(0.0)
}

#[no_mangle]
pub extern "C" fn baldi_player_z() -> f32 {
    GAME.lock().map(|g| g.player_z).unwrap_or(0.0)
}

#[no_mangle]
pub extern "C" fn baldi_notebooks() -> u32 {
    GAME.lock().map(|g| g.notebooks).unwrap_or(0)
}

#[no_mangle]
pub extern "C" fn baldi_notebook_taken() -> u32 {
    GAME.lock().map(|g| if g.notebook_taken { 1 } else { 0 }).unwrap_or(0)
}

#[no_mangle]
pub extern "C" fn baldi_elapsed_seconds() -> f32 {
    GAME.lock().map(|g| g.elapsed).unwrap_or(0.0)
}

#[cfg(test)]
mod tests {
    use super::GameState;

    #[test]
    fn movement_is_bounded_and_uses_input() {
        let mut game = GameState::new();
        game.input_y = 1.0;
        game.update(0.05);
        assert!(game.player_z > 0.0);
        game.input_x = 1.0;
        for _ in 0..100 { game.update(0.05); }
        assert!(game.player_x <= 2.25);
    }

    #[test]
    fn notebook_is_collected_in_interaction_range() {
        let mut game = GameState::new();
        game.player_z = 8.0;
        game.interact();
        assert!(game.notebook_taken);
        assert_eq!(game.notebooks, 1);
        game.interact();
        assert_eq!(game.notebooks, 1);
    }
}
