extern crate baldi_plus_rust;

use baldi_plus_rust::{
    door::DoorCore,
    inventory::ItemManagerCore,
    items::Items,
    warning::WarningScreenCore,
};


use baldi_plus_rust::{door::DoorCore, inventory::ItemManagerCore, items::Items, warning::WarningScreenCore};

fn main() {
    // Tiny smoke demo; the real game loop/rendering backend is a later port stage.
    let mut inventory = ItemManagerCore::new(5, 9);
    let _ = inventory.pickup_first_empty(Items::Bsoda);
    let mut door = DoorCore::default();
    let _ = door.open(true, false);
    let mut warning = WarningScreenCore::default();
    warning.update(false, false, false, false, true); // mobile touch
    println!("Rust port core initialized; inventory={}, door_open={}, warning={:?}",
        inventory.total_items(), door.open, warning.phase);
}
