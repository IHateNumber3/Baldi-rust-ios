//! Exact item identifier order from original `Items.cs`.
#[repr(u16)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Items {
    #[default] None = 0, Bsoda, ZestyBar, DoorLock, AlarmClock, DetentionKey,
    Quarter, Map, Wd40, Scissors, NanaPeel, DietBsoda, Teleporter, ChalkEraser,
    PortalPoster, PrincipalWhistle, Nametag, Tape, Boots, GrapplingHook, Apple,
    Points, BusPass, CircleKey, TriangleKey, SquareKey, PentagonKey, HexagonKey,
    WeirdKey, lostItem0, lostItem1, lostItem2, lostItem3, lostItem4, lostItem5,
    lostItem6, lostItem7, lostItem8, lostItem9, InvisibilityElixir,
    ReachExtender, StickerPack,
}
impl Items {
    pub const COUNT: usize = 42; // includes None
    pub const fn is_none(self) -> bool { matches!(self, Self::None) }
}
