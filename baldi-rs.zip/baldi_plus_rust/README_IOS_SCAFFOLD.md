# Baldi Rust iOS scaffold

This archive now contains a native iOS host and a Rust gameplay core.

## Included
- Rust static library target only (`autobins = false` avoids the old `main.rs` crate-link error).
- C ABI entry points for reset, frame update, touch movement, interaction, and state reads.
- UIKit first-person corridor prototype with touch joystick and USE button.
- XcodeGen project description and GitHub Actions workflow that builds an iOS `.app` and packages `Baldi.ipa`.

## Build
The GitHub Actions workflow expects this repository to contain the Rust project root and runs manually via `workflow_dispatch`.

The generated IPA is unsigned because the workflow does not contain an Apple signing certificate or provisioning profile. Import it into a sideloading tool that signs apps for your device. The IPA is a playable prototype scaffold, not a faithful recreation of the original game yet: the corridor and doors are placeholder rendering; the Rust state currently supports movement and collecting one test notebook.
